<template>
  <div class="events-page">

    <!-- ── Hero ─────────────────────────── -->
    <section id="events" class="page-hero">
      <div class="container">
        <p class="section-label animate-on-scroll">{{ tBy({ en: "What's On", km: 'ព្រឹត្តិការណ៍' }) }}</p>
        <h1 class="page-title animate-on-scroll delay-1">{{ tBy({ en: 'Art Events', km: 'ព្រឹត្តិការណ៍សិល្បៈ' }) }}</h1>
        <p class="page-subtitle animate-on-scroll delay-2">{{ tBy({ en: 'Exhibitions, festivals, and gatherings celebrating Cambodian creativity', km: 'ការតាំងបង្ហាញ ពិធីបុណ្យ និងការជួបជុំ' }) }}</p>
      </div>
      <div class="divider-gold animate-on-scroll delay-3" />
    </section>

    <!-- ── Category tabs ──────────────────── -->
    <section class="filters-bar">
      <div class="container">
        <div class="filter-chips">
          <button v-for="cat in eventCategories" :key="cat.v" class="filter-chip" :class="{ active: activeTab === cat.v }" @click="activeTab = cat.v">{{ tBy(cat.l) }}</button>
        </div>
      </div>
    </section>

    <!-- ── Featured event ─────────────────── -->
    <section id="featured-event" class="section featured-section" v-if="featured">
      <div class="container">
        <p class="section-label animate-on-scroll">{{ tBy({ en: 'Featured', km: 'ពិសេស' }) }}</p>
        <div class="featured-card animate-on-scroll delay-1">
          <div class="featured-media">
            <RAImage :src="featured.image" aspect="landscape" :watermark="false" />
            <span class="featured-cat-badge">{{ featured.category }}</span>
          </div>
          <div class="featured-body">
            <div class="event-date-block">
              <span class="edb-day">{{ fmtDay(featured.date) }}</span>
              <span class="edb-month">{{ fmtMonth(featured.date) }}</span>
              <span class="edb-year">{{ fmtYear(featured.date) }}</span>
            </div>
            <h2 class="featured-title">{{ featured.title }}</h2>
            <div class="event-meta-list">
              <div class="em-item">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                {{ featured.location }}
              </div>
              <div class="em-item">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                {{ fmtRange(featured.date, featured.end_date) }}
              </div>
            </div>
            <p class="featured-desc">{{ featured.description }}</p>
            <div class="featured-actions">
              <NuxtLink :to="`/events/${featured.slug}`" class="btn btn-primary">{{ tBy({ en: 'View Event', km: 'មើលព្រឹត្តិការណ៍' }) }}</NuxtLink>
              <button class="btn btn-outline">{{ tBy({ en: 'Add to Calendar', km: 'បន្ថែមទៅប្រតិទិន' }) }}</button>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ── All events list ─────────────────── -->
    <section id="all-events" class="section events-section">
      <div class="container">
        <div class="events-head animate-on-scroll">
          <div>
            <p class="section-label">{{ tBy({ en: 'All Events', km: 'ព្រឹត្តិការណ៍ទាំងអស់' }) }}</p>
            <h2 class="section-title animate-on-scroll delay-1">{{ tBy({ en: 'Don\'t Miss Out', km: 'កុំខក' }) }}</h2>
          </div>
        </div>

        <div class="events-list">
          <NuxtLink
            v-for="(ev, i) in filteredEvents"
            :key="ev.id"
            :to="`/events/${ev.slug}`"
            class="event-row animate-on-scroll"
            :class="`delay-${i + 1}`"
          >
            <div class="er-date">
              <span class="er-day">{{ fmtDay(ev.date) }}</span>
              <span class="er-month">{{ fmtMonth(ev.date) }}</span>
            </div>
            <div class="er-img">
              <img :src="ev.image" :alt="ev.title" loading="lazy" />
            </div>
            <div class="er-body">
              <span class="tag tag-gold">{{ ev.category }}</span>
              <h3 class="er-title">{{ ev.title }}</h3>
              <p class="er-loc">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                {{ ev.location }}
              </p>
              <p class="er-desc">{{ ev.description }}</p>
            </div>
            <div class="er-arrow">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
            </div>
          </NuxtLink>
        </div>

        <div v-if="filteredEvents.length === 0" class="empty-state animate-on-scroll">
          <p>{{ tBy({ en: 'No events in this category', km: 'គ្មានព្រឹត្តិការណ៍ក្នុងប្រភេទនេះ' }) }}</p>
        </div>
      </div>
    </section>

    <!-- ── CTA ───────────────────────────── -->
    <section id="events-cta" class="section cta-section">
      <div class="container">
        <div class="cta-card animate-on-scroll">
          <span class="cta-emoji">🎪</span>
          <h2 class="cta-title">{{ tBy({ en: 'Organising an art event?', km: 'រៀបចំព្រឹត្តិការណ៍សិល្បៈ?' }) }}</h2>
          <p>{{ tBy({ en: 'List your exhibition or workshop on RamaGallery and reach thousands of art lovers.', km: 'ដាក់ការតាំងបង្ហាញ ឬ Workshop របស់អ្នកនៅ RamaGallery' }) }}</p>
          <NuxtLink to="/contact" class="btn btn-primary">{{ tBy({ en: 'List Your Event', km: 'ដាក់ព្រឹត្តិការណ៍' }) }}</NuxtLink>
        </div>
      </div>
    </section>

  </div>
</template>

<script setup lang="ts">
import pagesData from '~/assets/json/pages.json'
import { useTBy } from '~/composables/useTBy'

const { tBy } = useTBy()
useScrollAnimation()

const activeTab = ref('all')
const eventCategories = [
  { v: 'all',         l: { en: 'All',        km: 'ទាំងអស់' } },
  { v: 'exhibition',  l: { en: 'Exhibition',  km: 'ការតាំងបង្ហាញ' } },
  { v: 'photography', l: { en: 'Photography', km: 'ថតរូប' } },
  { v: 'hackathon',   l: { en: 'Hackathon',   km: 'ការប្រកួត' } },
]

const filteredEvents = computed(() =>
  activeTab.value === 'all'
    ? pagesData.events
    : pagesData.events.filter(e => e.category === activeTab.value)
)
const featured = computed(() => pagesData.events.find(e => e.featured))

const fmtDay   = (d: string) => new Date(d).getDate()
const fmtMonth = (d: string) => new Date(d).toLocaleString('en', { month: 'short' })
const fmtYear  = (d: string) => new Date(d).getFullYear()
const fmtRange = (s: string, e: string) => {
  const start = new Date(s)
  const end = new Date(e)
  return `${start.toLocaleDateString('en',{month:'long',day:'numeric'})} – ${end.toLocaleDateString('en',{day:'numeric',year:'numeric'})}`
}

useSeoMeta({ title: 'Events — RamaGallery', description: 'Cambodian art events, exhibitions, and festivals.' })
</script>

<style scoped lang="scss">
.page-hero { padding: 5.5rem 0 3rem; text-align: center; background: linear-gradient(180deg, var(--color-bg-secondary) 0%, var(--color-bg) 100%); border-bottom: 1px solid var(--color-border); }
.page-title { font-size: clamp(2.5rem, 6vw, 4.5rem); margin: 0.5rem 0; }
.page-subtitle { color: var(--color-text-secondary); max-width: 520px; margin: 0 auto 1.5rem; }
.divider-gold { margin: 0 auto; }

.filters-bar { padding: 0.875rem 0; border-bottom: 1px solid var(--color-border); background: var(--color-bg-overlay); backdrop-filter: blur(16px); position: sticky; top: var(--header-height); z-index: 40; }
.filter-chips { display: flex; gap: 0.4rem; flex-wrap: wrap; }
.filter-chip { padding: 0.38rem 1rem; border-radius: 20px; border: 1px solid var(--color-border); background: transparent; color: var(--color-text-secondary); font-size: 0.78rem; font-weight: 500; cursor: pointer; transition: all var(--transition); font-family: var(--font-sans); &:hover { border-color: var(--color-gold); color: var(--color-gold); } &.active { background: var(--color-gold); border-color: var(--color-gold); color: #fff; } }

.featured-section { background: var(--color-bg-secondary); }
.featured-card { display: grid; grid-template-columns: 1.2fr 1fr; gap: 0; background: var(--color-bg-card); border: 1px solid var(--color-border); border-radius: var(--radius-lg); overflow: hidden; box-shadow: var(--shadow-lg); @media (max-width: 768px) { grid-template-columns: 1fr; } }
.featured-media { position: relative; min-height: 320px; }
.featured-cat-badge { position: absolute; top: 1.25rem; left: 1.25rem; background: var(--color-gold); color: #fff; font-size: 0.67rem; font-weight: 700; letter-spacing: 0.14em; text-transform: uppercase; padding: 0.3rem 0.875rem; border-radius: var(--radius-sm); z-index: 5; }
.featured-body { padding: 2.5rem; display: flex; flex-direction: column; gap: 1.25rem; }
.event-date-block { display: flex; align-items: baseline; gap: 0.4rem; }
.edb-day { font-family: var(--font-display); font-size: 3rem; color: var(--color-gold); line-height: 1; }
.edb-month { font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.12em; color: var(--color-text-muted); }
.edb-year { font-size: 0.8rem; color: var(--color-text-muted); }
.featured-title { font-family: var(--font-display); font-size: clamp(1.5rem, 3vw, 2.2rem); line-height: 1.15; }
.event-meta-list { display: flex; flex-direction: column; gap: 0.5rem; }
.em-item { display: flex; align-items: center; gap: 0.5rem; font-size: 0.875rem; color: var(--color-text-secondary); }
.featured-desc { font-size: 0.9rem; color: var(--color-text-secondary); line-height: 1.7; }
.featured-actions { display: flex; gap: 0.875rem; flex-wrap: wrap; }

.events-head { margin-bottom: 2rem; }
.section-title { font-size: clamp(1.75rem, 4vw, 2.75rem); margin-top: 0.5rem; }

.events-list { display: flex; flex-direction: column; }
.event-row {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 1.25rem 1rem;
  border-bottom: 1px solid var(--color-border);
  text-decoration: none;
  border-radius: var(--radius-md);
  transition: all var(--transition);

  &:first-child { border-top: 1px solid var(--color-border); }
  &:hover { background: var(--color-bg-secondary); padding-left: 1.5rem; }
  &:hover .er-title { color: var(--color-gold); }
  &:hover .er-arrow { transform: translateX(4px); color: var(--color-gold); }
}

.er-date { display: flex; flex-direction: column; align-items: center; min-width: 44px; flex-shrink: 0; }
.er-day { font-family: var(--font-display); font-size: 1.75rem; color: var(--color-gold); line-height: 1; }
.er-month { font-size: 0.68rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-text-muted); }
.er-img { width: 80px; height: 56px; border-radius: var(--radius-sm); overflow: hidden; flex-shrink: 0; img { width: 100%; height: 100%; object-fit: cover; } }
.er-body { flex: 1; min-width: 0; }
.er-title { font-family: var(--font-display); font-size: 1.05rem; font-weight: 400; color: var(--color-text-primary); margin: 0.25rem 0 0.375rem; transition: color var(--transition); }
.er-loc { display: flex; align-items: center; gap: 0.35rem; font-size: 0.78rem; color: var(--color-text-muted); margin-bottom: 0.25rem; }
.er-desc { font-size: 0.82rem; color: var(--color-text-secondary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.er-arrow { color: var(--color-text-muted); transition: all var(--transition); flex-shrink: 0; }

.empty-state { text-align: center; padding: 4rem; color: var(--color-text-muted); }

.cta-section { background: var(--color-bg-secondary); }
.cta-card { text-align: center; max-width: 600px; margin: 0 auto; padding: 4rem 2rem; display: flex; flex-direction: column; align-items: center; gap: 1.25rem; .cta-emoji { font-size: 3rem; } }
.cta-title { font-family: var(--font-display); font-size: clamp(1.75rem, 4vw, 2.5rem); }
.cta-card p { color: var(--color-text-secondary); max-width: 400px; }
</style>
