<template>
  <div class="auth-page">
    <div class="auth-left">
      <div class="auth-art">
        <img src="https://picsum.photos/seed/auth-art/800/1200" alt="Cambodian art" class="auth-art-img" draggable="false" />
        <div class="auth-art-overlay" />
        <div class="auth-art-caption">
          <p class="section-label">Featured Artist</p>
          <p class="caption-name">Sophea Khun</p>
          <p class="caption-work">Apsara in Gold, 2024</p>
        </div>
      </div>
    </div>

    <div class="auth-right">
      <div class="auth-box">
        <!-- Logo -->
        <NuxtLink to="/" class="auth-logo">
          <span class="logo-icon">ར</span>
          <span>RamaGallery</span>
        </NuxtLink>

        <!-- Tabs -->
        <div class="auth-tabs">
          <button :class="['auth-tab', { active: mode === 'password' }]" @click="mode = 'password'">Password</button>
          <button :class="['auth-tab', { active: mode === 'magic' }]" @click="mode = 'magic'">Magic link</button>
          <button :class="['auth-tab', { active: mode === 'otp' }]" @click="mode = 'otp'">OTP</button>
        </div>

        <h1 class="auth-title">{{ t('auth.sign_in') }}</h1>

        <!-- Google -->
        <button class="google-btn" @click="loginGoogle">
          <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
          {{ t('auth.google') }}
        </button>

        <div class="divider-or"><span>or</span></div>

        <!-- Password form -->
        <form v-if="mode === 'password'" class="auth-form" @submit.prevent="handleLogin">
          <div class="field">
            <label class="field-label">{{ t('auth.email') }}</label>
            <input v-model="email" type="email" class="input" :placeholder="t('auth.email')" required />
          </div>
          <div class="field">
            <label class="field-label">{{ t('auth.password') }}</label>
            <div class="password-wrap">
              <input v-model="password" :type="showPass ? 'text' : 'password'" class="input" :placeholder="t('auth.password')" required />
              <button type="button" class="pass-toggle" @click="showPass = !showPass">
                {{ showPass ? '🙈' : '👁' }}
              </button>
            </div>
            <NuxtLink :to="localePath('/forgot-password')" class="forgot-link">{{ t('auth.forgot') }}</NuxtLink>
          </div>

          <p v-if="error" class="auth-error">{{ error }}</p>

          <button type="submit" class="btn btn-primary submit-btn" :disabled="auth.isLoading">
            <span v-if="auth.isLoading" class="spinner" />
            <span v-else>{{ t('auth.sign_in') }}</span>
          </button>
        </form>

        <!-- Magic link form -->
        <form v-else-if="mode === 'magic'" class="auth-form" @submit.prevent="handleMagicLink">
          <div class="field">
            <label class="field-label">{{ t('auth.email') }}</label>
            <input v-model="email" type="email" class="input" :placeholder="t('auth.email')" required />
          </div>
          <button type="submit" class="btn btn-primary submit-btn">
            {{ t('auth.magic_link') }}
          </button>
          <p v-if="magicSent" class="auth-success">Check your email for the magic link!</p>
        </form>

        <!-- OTP form -->
        <form v-else class="auth-form" @submit.prevent="handleOtp">
          <div class="field">
            <label class="field-label">{{ t('auth.phone') }}</label>
            <input v-model="phone" type="tel" class="input" placeholder="+855 ..." />
          </div>
          <button v-if="!otpSent" type="button" class="btn btn-outline submit-btn" @click="sendOtp">
            Send OTP
          </button>
          <template v-if="otpSent">
            <div class="field">
              <label class="field-label">{{ t('auth.otp') }}</label>
              <div class="otp-inputs">
                <input
                  v-for="i in 6"
                  :key="i"
                  v-model="otpDigits[i-1]"
                  type="text"
                  maxlength="1"
                  class="otp-input"
                  @input="focusNext($event, i)"
                />
              </div>
            </div>
            <button type="submit" class="btn btn-primary submit-btn">Verify OTP</button>
          </template>
        </form>

        <p class="auth-switch">
          {{ t('auth.no_account') }}
          <NuxtLink :to="localePath('/register')">{{ t('nav.register') }}</NuxtLink>
        </p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ layout: 'default', middleware: 'guest' })

const { t } = useI18n()
const localePath = useLocalePath()
const auth = useAuthStore()
const router = useRouter()

const mode = ref<'password' | 'magic' | 'otp'>('password')
const email = ref('')
const password = ref('')
const phone = ref('')
const showPass = ref(false)
const error = ref('')
const magicSent = ref(false)
const otpSent = ref(false)
const otpDigits = ref<string[]>(Array(6).fill(''))

const handleLogin = async () => {
  error.value = ''
  const result = await auth.login(email.value, password.value)
  if (result.success) router.push(localePath('/dashboard'))
  else error.value = auth.error ?? 'Login failed'
}

const loginGoogle = async () => {
  await auth.loginWithGoogle()
  router.push(localePath('/dashboard'))
}

const handleMagicLink = async () => {
  await new Promise(r => setTimeout(r, 600))
  magicSent.value = true
}

const sendOtp = async () => {
  otpSent.value = true
}

const handleOtp = async () => {
  const otp = otpDigits.value.join('')
  if (otp.length < 6) return
  await auth.login(phone.value + '@otp.ramagallery.com', otp)
  router.push(localePath('/dashboard'))
}

const focusNext = (e: Event, index: number) => {
  const target = e.target as HTMLInputElement
  if (target.value && index < 6) {
    const next = target.parentElement?.children[index] as HTMLInputElement
    next?.focus()
  }
}

useSeoMeta({ title: 'Sign In — RamaGallery' })
</script>

<style scoped lang="scss">
.auth-page {
  display: grid;
  grid-template-columns: 1fr 1fr;
  min-height: calc(100vh - var(--header-height));

  @media (max-width: 768px) { grid-template-columns: 1fr; }
}

.auth-left {
  @media (max-width: 768px) { display: none; }
}

.auth-art {
  position: relative;
  height: 100%;
  overflow: hidden;
}

.auth-art-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  pointer-events: none;
}

.auth-art-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(to top, rgba(10,8,5,0.8) 0%, transparent 50%);
}

.auth-art-caption {
  position: absolute;
  bottom: 2.5rem;
  left: 2.5rem;
  color: #fff;

  .section-label { color: var(--color-gold); margin-bottom: 0.375rem; }
}

.caption-name { font-family: var(--font-display); font-size: 1.5rem; font-weight: 400; margin-bottom: 0.25rem; }
.caption-work { font-size: 0.875rem; opacity: 0.7; }

.auth-right {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 3rem 2rem;
  background: var(--color-bg);
}

.auth-box {
  width: 100%;
  max-width: 400px;
}

.auth-logo {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  text-decoration: none;
  margin-bottom: 2.5rem;
  font-family: var(--font-display);
  font-size: 1.25rem;
  color: var(--color-text-primary);

  .logo-icon { font-size: 1.5rem; color: var(--color-gold); }
}

.auth-tabs {
  display: flex;
  background: var(--color-bg-secondary);
  border-radius: 6px;
  padding: 3px;
  margin-bottom: 1.75rem;
  gap: 2px;
}

.auth-tab {
  flex: 1;
  padding: 0.5rem;
  font-size: 0.8125rem;
  font-weight: 400;
  border: none;
  border-radius: 4px;
  background: transparent;
  color: var(--color-text-secondary);
  cursor: pointer;
  transition: all var(--transition);

  &.active {
    background: var(--color-bg-card);
    color: var(--color-text-primary);
    box-shadow: 0 1px 4px rgba(0,0,0,0.08);
  }
}

.auth-title {
  font-family: var(--font-display);
  font-size: 2rem;
  font-weight: 400;
  color: var(--color-text-primary);
  margin-bottom: 1.5rem;
}

.google-btn {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  padding: 0.8rem;
  background: var(--color-bg-card);
  border: 1px solid var(--color-border);
  border-radius: 4px;
  font-family: var(--font-sans);
  font-size: 0.9rem;
  color: var(--color-text-primary);
  cursor: pointer;
  transition: all var(--transition);

  &:hover { border-color: var(--color-border-strong); background: var(--color-bg-secondary); }
}

.divider-or {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin: 1.25rem 0;
  color: var(--color-text-muted);
  font-size: 0.8rem;

  &::before, &::after {
    content: '';
    flex: 1;
    height: 1px;
    background: var(--color-border);
  }
}

.auth-form { display: flex; flex-direction: column; gap: 1.25rem; }

.field { display: flex; flex-direction: column; gap: 0.5rem; }
.field-label { font-size: 0.8125rem; font-weight: 500; color: var(--color-text-secondary); }

.password-wrap { position: relative; display: flex; }
.pass-toggle {
  position: absolute;
  right: 0.75rem;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  cursor: pointer;
  font-size: 0.9rem;
}

.forgot-link {
  font-size: 0.8rem;
  color: var(--color-gold);
  text-decoration: none;
  align-self: flex-end;
  margin-top: -0.25rem;
}

.submit-btn { width: 100%; padding: 0.875rem; font-size: 0.9375rem; }

.auth-error { font-size: 0.875rem; color: #e53e3e; }
.auth-success { font-size: 0.875rem; color: #38a169; }

.otp-inputs { display: flex; gap: 0.5rem; }
.otp-input {
  width: 44px;
  height: 52px;
  text-align: center;
  font-size: 1.25rem;
  font-weight: 600;
  border: 1px solid var(--color-border);
  border-radius: 4px;
  background: var(--color-bg-secondary);
  color: var(--color-text-primary);
  outline: none;
  transition: border-color var(--transition);

  &:focus { border-color: var(--color-gold); }
}

.auth-switch {
  margin-top: 1.5rem;
  font-size: 0.875rem;
  color: var(--color-text-muted);
  text-align: center;

  a { color: var(--color-gold); text-decoration: none; }
}

.spinner {
  width: 18px;
  height: 18px;
  border: 2px solid rgba(255,255,255,0.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
  display: inline-block;
}

@keyframes spin { to { transform: rotate(360deg); } }
</style>
