<template>
  <div class="blogs-page">

    <!-- ── Hero ─────────────────────────────── -->
    <section id="blogs" class="page-hero">
      <div class="container">
        <p class="section-label animate-on-scroll">{{ tBy({ en: 'Stories & Insights', km: 'រឿងរ៉ាវ' }) }}</p>
        <h1 class="page-title animate-on-scroll delay-1">{{ tBy({ en: 'The Journal', km: 'ទស្សនាវដ្តី' }) }}</h1>
        <p class="page-subtitle animate-on-scroll delay-2">{{ tBy({ en: 'Perspectives on Cambodian art, artists, and culture', km: 'ទស្សនៈលើសិល្បៈ វិចិត្រករ និងវប្បធម៌ខ្មែរ' }) }}</p>
      </div>
    </section>

    <!-- ── Search + Filter ───────────────────── -->
    <section class="filter-section">
      <div class="container filter-row">
        <div class="search-wrap">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.35-4.35"/></svg>
          <input v-model="searchQ" type="text" class="search-input" :placeholder="tBy({ en: 'Search articles…', km: 'ស្វែងរកអត្ថបទ…' })" />
        </div>
        <div class="cat-chips">
          <button v-for="c in blogCategories" :key="c" class="filter-chip" :class="{ active: activeCategory === c }" @click="activeCategory = c">{{ c }}</button>
        </div>
      </div>
    </section>

    <!-- ── Featured post ─────────────────────── -->
    <section id="featured-post" class="section" v-if="featured && !searchQ">
      <div class="container">
        <p class="section-label animate-on-scroll">{{ tBy({ en: 'Editor\'s Pick', km: 'ការជ្រើសរើសសម្រាក់' }) }}</p>
        <NuxtLink :to="`/blogs/${featured.slug}`" class="featured-post animate-on-scroll delay-1">
          <div class="fp-media">
            <RAImage :src="featured.image" aspect="wide" :watermark="false" />
            <span class="fp-cat">{{ featured.category }}</span>
          </div>
          <div class="fp-body">
            <div class="fp-meta">
              <img :src="featured.authorAvatar" :alt="featured.author" class="fp-avatar" />
              <span>{{ featured.author }}</span>
              <span class="dot">·</span>
              <span>{{ fmtDate(featured.date) }}</span>
              <span class="dot">·</span>
              <span>{{ featured.readTime }} min read</span>
            </div>
            <h2 class="fp-title">{{ featured.title }}</h2>
            <p class="fp-excerpt">{{ featured.excerpt }}</p>
            <div class="fp-tags">
              <span v-for="tag in featured.tags" :key="tag" class="tag">{{ tag }}</span>
            </div>
          </div>
        </NuxtLink>
      </div>
    </section>

    <!-- ── Blog grid ─────────────────────────── -->
    <section id="all-posts" class="section blog-section">
      <div class="container">
        <div class="blogs-header animate-on-scroll">
          <p class="section-label">{{ tBy({ en: 'All Articles', km: 'អត្ថបទទាំងអស់' }) }}</p>
          <span class="post-count">{{ filteredBlogs.length }} {{ tBy({ en: 'posts', km: 'ài' }) }}</span>
        </div>
        <div class="blogs-grid">
          <NuxtLink
            v-for="(blog, i) in filteredBlogs"
            :key="blog.id"
            :to="`/blogs/${blog.slug}`"
            class="blog-card card animate-on-scroll"
            :class="`delay-${(i % 6) + 1}`"
          >
            <div class="bc-media">
              <img :src="blog.image" :alt="blog.title" loading="lazy" class="bc-img" />
              <span class="bc-cat">{{ blog.category }}</span>
            </div>
            <div class="bc-body">
              <div class="bc-meta">
                <img :src="blog.authorAvatar" :alt="blog.author" class="bc-avatar" />
                <span class="bc-author">{{ blog.author }}</span>
                <span class="dot">·</span>
                <span class="bc-time">{{ blog.readTime }} min</span>
              </div>
              <h3 class="bc-title">{{ blog.title }}</h3>
              <p class="bc-excerpt">{{ blog.excerpt }}</p>
              <div class="bc-footer">
                <span class="bc-date">{{ fmtDate(blog.date) }}</span>
                <div class="bc-tags">
                  <span v-for="tag in blog.tags.slice(0,2)" :key="tag" class="tag">{{ tag }}</span>
                </div>
              </div>
            </div>
          </NuxtLink>
        </div>

        <div v-if="filteredBlogs.length === 0" class="empty-state animate-on-scroll">
          <p>{{ tBy({ en: 'No articles found', km: 'រកមិនឃើញអត្ថបទ' }) }}</p>
          <button class="btn btn-outline" @click="searchQ = ''; activeCategory = 'All'">{{ tBy({ en: 'Clear filters', km: 'លុបតម្រង' }) }}</button>
        </div>
      </div>
    </section>

    <!-- ── Newsletter ───────────────────────── -->
    <section id="newsletter" class="section newsletter-section">
      <div class="container">
        <div class="newsletter-card animate-on-scroll">
          <p class="section-label">{{ tBy({ en: 'Stay in the loop', km: 'ត្រូវបានជ្រាបដំណឹង' }) }}</p>
          <h2 class="nl-title">{{ tBy({ en: 'Art news, delivered weekly', km: 'ព័ត៌មានសិល្បៈ ប្រចាំសប្តាហ៍' }) }}</h2>
          <p class="nl-sub">{{ tBy({ en: 'Join 3,000+ collectors and artists getting the best Cambodian art stories.', km: 'ចូលរួមជាមួយ 3,000+ អ្នកប្រមូល' }) }}</p>
          <div class="nl-form">
            <input v-model="nlEmail" type="email" class="input nl-input" :placeholder="tBy({ en: 'Your email address', km: 'អ៊ីមែលរបស់អ្នក' })" />
            <button class="btn btn-primary nl-btn" @click="handleSubscribe">
              <span v-if="subscribed">✓ {{ tBy({ en: 'Subscribed!', km: 'បានជាវ!' }) }}</span>
              <span v-else>{{ tBy({ en: 'Subscribe', km: 'ជាវ' }) }}</span>
            </button>
          </div>
        </div>
      </div>
    </section>

  </div>
</template>

<script setup lang="ts">
import { useTBy } from '~/composables/useTBy'

const { tBy } = useTBy()
useScrollAnimation()

const searchQ = ref('')
const activeCategory = ref('All')
const nlEmail = ref('')
const subscribed = ref(false)

const blogCategories = ['All', 'Artist Stories', 'Technique', 'Culture', 'Market', 'AI & Art']

const blogs = [
  { id: 1, slug: 'reviving-hol-lboeuk', title: 'Reviving Hol Lboeuk: Ancient Silk for Modern Collectors', excerpt: 'Third-generation weaver Channary Lim explains how she is breathing new life into Cambodia\'s most endangered textile art form using natural indigo dyes and hand looms.', author: 'Sreyleak Pov', authorAvatar: 'https://api.dicebear.com/7.x/personas/svg?seed=sreyleak', date: '2025-06-10', readTime: 6, category: 'Artist Stories', image: 'https://picsum.photos/seed/blog1/800/500', tags: ['silk', 'traditional', 'interview'], featured: true },
  { id: 2, slug: 'angkor-as-muse', title: 'Angkor as Muse: Why Ancient Ruins Inspire Contemporary Artists', excerpt: 'A deep dive into how the temples of Angkor continue to shape the visual language of Cambodian artists across every medium from oil painting to generative code.', author: 'Ratha Sok', authorAvatar: 'https://api.dicebear.com/7.x/personas/svg?seed=ratha', date: '2025-06-03', readTime: 8, category: 'Culture', image: 'https://picsum.photos/seed/blog2/800/500', tags: ['angkor', 'inspiration', 'history'], featured: false },
  { id: 3, slug: 'ai-in-cambodian-art', title: 'AI Tools Are Changing How Cambodian Artists Work', excerpt: 'From automatic captioning to style analysis, we explore how AI is augmenting — not replacing — creative practice in the Kingdom.', author: 'Kosal Heng', authorAvatar: 'https://api.dicebear.com/7.x/personas/svg?seed=kosal', date: '2025-05-28', readTime: 5, category: 'AI & Art', image: 'https://picsum.photos/seed/blog3/800/500', tags: ['AI', 'technology', 'future'], featured: false },
  { id: 4, slug: 'collecting-cambodian-art', title: 'A Beginner\'s Guide to Collecting Cambodian Art', excerpt: 'Everything you need to know before buying your first piece — provenance, authentication, pricing, and building a meaningful collection over time.', author: 'Bopha Nhem', authorAvatar: 'https://api.dicebear.com/7.x/personas/svg?seed=bopha', date: '2025-05-20', readTime: 7, category: 'Market', image: 'https://picsum.photos/seed/blog4/800/500', tags: ['collecting', 'guide', 'market'], featured: false },
  { id: 5, slug: 'digital-art-cambodia', title: 'The Rise of Digital Art in Cambodia', excerpt: 'How a new generation of Khmer artists are using tablets, generative algorithms, and NFT platforms to carve out a global space for Cambodian digital expression.', author: 'Sreyleak Pov', authorAvatar: 'https://api.dicebear.com/7.x/personas/svg?seed=sreyleak', date: '2025-05-12', readTime: 6, category: 'Technique', image: 'https://picsum.photos/seed/blog5/800/500', tags: ['digital', 'NFT', 'generative'], featured: false },
  { id: 6, slug: 'bronze-casting-tradition', title: 'The Living Art of Khmer Bronze Casting', excerpt: 'Vireak Chhem opens his Battambang workshop to show how the 1,000-year-old lost-wax process survives and thrives in modern Cambodia.', author: 'Ratha Sok', authorAvatar: 'https://api.dicebear.com/7.x/personas/svg?seed=ratha', date: '2025-05-05', readTime: 9, category: 'Technique', image: 'https://picsum.photos/seed/blog6/800/500', tags: ['sculpture', 'bronze', 'craft'], featured: false },
]

const featured = computed(() => blogs.find(b => b.featured))

const filteredBlogs = computed(() => {
  let list = blogs.filter(b => !b.featured || searchQ.value || activeCategory.value !== 'All')
  if (activeCategory.value !== 'All') list = list.filter(b => b.category === activeCategory.value)
  if (searchQ.value) {
    const q = searchQ.value.toLowerCase()
    list = blogs.filter(b => b.title.toLowerCase().includes(q) || b.excerpt.toLowerCase().includes(q) || b.tags.some(t => t.toLowerCase().includes(q)))
  }
  return list
})

function fmtDate(d: string) {
  return new Date(d).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
}

async function handleSubscribe() {
  if (!nlEmail.value) return
  await new Promise(r => setTimeout(r, 600))
  subscribed.value = true
}

useSeoMeta({ title: 'Journal — RamaGallery', description: 'Stories, insights, and perspectives on Cambodian art.' })
</script>

<style scoped lang="scss">
.page-hero { padding: 5.5rem 0 3rem; text-align: center; background: linear-gradient(180deg, var(--color-bg-secondary) 0%, var(--color-bg) 100%); border-bottom: 1px solid var(--color-border); }
.page-title { font-size: clamp(2.5rem, 6vw, 4.5rem); margin: 0.5rem 0; }
.page-subtitle { color: var(--color-text-secondary); max-width: 520px; margin: 0 auto; }

.filter-section { padding: 1rem 0; border-bottom: 1px solid var(--color-border); background: var(--color-bg-overlay); backdrop-filter: blur(16px); position: sticky; top: var(--header-height); z-index: 40; }
.filter-row { display: flex; align-items: center; gap: 1.25rem; flex-wrap: wrap; }
.search-wrap { display: flex; align-items: center; gap: 0.625rem; padding: 0.45rem 1rem; background: var(--color-bg-secondary); border: 1px solid var(--color-border); border-radius: var(--radius-full); color: var(--color-text-muted); transition: border-color var(--transition); min-width: 200px; &:focus-within { border-color: var(--color-gold); } }
.search-input { background: none; border: none; outline: none; font-size: 0.85rem; color: var(--color-text-primary); font-family: var(--font-sans); flex: 1; &::placeholder { color: var(--color-text-muted); } }
.cat-chips { display: flex; gap: 0.35rem; flex-wrap: wrap; }
.filter-chip { padding: 0.35rem 0.875rem; border-radius: var(--radius-full); border: 1px solid var(--color-border); background: transparent; color: var(--color-text-secondary); font-size: 0.77rem; font-weight: 500; cursor: pointer; font-family: var(--font-sans); transition: all var(--transition); &:hover { border-color: var(--color-gold); color: var(--color-gold); } &.active { background: var(--color-gold); border-color: var(--color-gold); color: #fff; } }

// Featured post
.featured-post { display: grid; grid-template-columns: 1.3fr 1fr; gap: 0; background: var(--color-bg-card); border: 1px solid var(--color-border); border-radius: var(--radius-lg); overflow: hidden; text-decoration: none; box-shadow: var(--shadow-md); transition: all var(--transition); &:hover { box-shadow: var(--shadow-xl); transform: translateY(-2px); } &:hover .fp-title { color: var(--color-gold); } @media (max-width: 768px) { grid-template-columns: 1fr; } }
.fp-media { position: relative; min-height: 300px; }
.fp-cat { position: absolute; top: 1.25rem; left: 1.25rem; background: var(--color-gold); color: #fff; font-size: 0.67rem; font-weight: 700; letter-spacing: 0.14em; text-transform: uppercase; padding: 0.3rem 0.875rem; border-radius: var(--radius-sm); z-index: 5; }
.fp-body { padding: 2rem 2rem 2rem 2.25rem; display: flex; flex-direction: column; gap: 1rem; }
.fp-meta { display: flex; align-items: center; gap: 0.5rem; font-size: 0.78rem; color: var(--color-text-muted); }
.fp-avatar { width: 24px; height: 24px; border-radius: 50%; object-fit: cover; }
.dot { opacity: 0.4; }
.fp-title { font-family: var(--font-display); font-size: clamp(1.4rem, 3vw, 2rem); line-height: 1.2; transition: color var(--transition); }
.fp-excerpt { font-size: 0.9rem; color: var(--color-text-secondary); line-height: 1.7; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }
.fp-tags { display: flex; gap: 0.375rem; flex-wrap: wrap; }

// Blog grid
.blog-section { background: var(--color-bg-secondary); }
.blogs-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 2rem; }
.post-count { font-size: 0.8rem; color: var(--color-text-muted); }
.blogs-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.25rem; @media (max-width: 1024px) { grid-template-columns: repeat(2, 1fr); } @media (max-width: 580px) { grid-template-columns: 1fr; } }

.blog-card { display: flex; flex-direction: column; text-decoration: none; overflow: hidden; transition: all var(--transition); &:hover { transform: translateY(-4px); box-shadow: var(--shadow-lg); } &:hover .bc-title { color: var(--color-gold); } }
.bc-media { position: relative; height: 180px; overflow: hidden; }
.bc-img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.6s ease; .blog-card:hover & { transform: scale(1.04); } }
.bc-cat { position: absolute; top: 0.875rem; left: 0.875rem; background: var(--color-gold); color: #fff; font-size: 0.62rem; font-weight: 700; letter-spacing: 0.14em; text-transform: uppercase; padding: 0.25rem 0.7rem; border-radius: var(--radius-sm); }
.bc-body { padding: 1.25rem; flex: 1; display: flex; flex-direction: column; gap: 0.625rem; }
.bc-meta { display: flex; align-items: center; gap: 0.4rem; font-size: 0.75rem; color: var(--color-text-muted); }
.bc-avatar { width: 20px; height: 20px; border-radius: 50%; object-fit: cover; }
.bc-author { color: var(--color-text-secondary); font-weight: 500; }
.bc-title { font-family: var(--font-display); font-size: 1.05rem; line-height: 1.3; color: var(--color-text-primary); transition: color var(--transition); }
.bc-excerpt { font-size: 0.83rem; color: var(--color-text-secondary); line-height: 1.65; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; flex: 1; }
.bc-footer { display: flex; align-items: center; justify-content: space-between; margin-top: auto; padding-top: 0.75rem; border-top: 1px solid var(--color-border); }
.bc-date { font-size: 0.73rem; color: var(--color-text-muted); }
.bc-tags { display: flex; gap: 0.3rem; }

.empty-state { text-align: center; padding: 4rem; display: flex; flex-direction: column; align-items: center; gap: 1rem; color: var(--color-text-muted); }

// Newsletter
.newsletter-section { background: var(--color-text-primary); .dark & { background: var(--color-bg-secondary); } }
.newsletter-card { max-width: 580px; margin: 0 auto; text-align: center; display: flex; flex-direction: column; align-items: center; gap: 1rem; }
.newsletter-card .section-label { color: var(--color-gold); }
.nl-title { font-family: var(--font-display); font-size: clamp(1.75rem, 4vw, 2.75rem); color: var(--color-bg); .dark & { color: var(--color-text-primary); } }
.nl-sub { font-size: 0.95rem; color: rgba(240,236,228,0.65); .dark & { color: var(--color-text-secondary); } }
.nl-form { display: flex; gap: 0.75rem; width: 100%; max-width: 420px; flex-wrap: wrap; }
.nl-input { flex: 1; background: rgba(255,255,255,0.1); border-color: rgba(255,255,255,0.2); color: #fff; &::placeholder { color: rgba(255,255,255,0.45); } &:focus { background: rgba(255,255,255,0.15); border-color: var(--color-gold); box-shadow: none; } .dark & { background: var(--color-bg-secondary); border-color: var(--color-border); color: var(--color-text-primary); } }
.nl-btn { flex-shrink: 0; }
</style>
