<template>
  <div class="dashboard">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div class="sidebar-user">
        <img :src="auth.user?.avatar ?? ''" :alt="auth.displayName" class="sidebar-avatar" />
        <div>
          <p class="sidebar-name">{{ auth.displayName }}</p>
          <p class="sidebar-role">{{ auth.user?.role }}</p>
        </div>
      </div>

      <nav class="sidebar-nav">
        <button
          v-for="tab in tabs"
          :key="tab.key"
          :class="['sidebar-link', { active: activeTab === tab.key }]"
          @click="activeTab = tab.key"
        >
          <span class="link-icon" v-html="tab.icon" />
          <span>{{ tBy(tab.label) }}</span>
        </button>
      </nav>

      <div class="sidebar-footer">
        <NuxtLink :to="localePath('/settings')" class="sidebar-link">
          <span class="link-icon">⚙</span>
          <span>{{ t('common.edit') }} Profile</span>
        </NuxtLink>
        <button class="sidebar-link danger" @click="handleLogout">
          <span class="link-icon">→</span>
          <span>{{ t('nav.logout') }}</span>
        </button>
      </div>
    </aside>

    <!-- Main -->
    <main class="dash-main">
      <!-- Overview -->
      <div v-if="activeTab === 'overview'" class="tab-content">
        <div class="dash-header">
          <div>
            <p class="section-label">{{ t('dashboard.title') }}</p>
            <h1 class="dash-title">{{ t('dashboard.welcome') }}, {{ auth.displayName }} 👋</h1>
          </div>
          <NuxtLink :to="localePath('/dashboard/upload')" class="btn btn-primary">
            + {{ t('dashboard.upload') }}
          </NuxtLink>
        </div>

        <!-- Stats cards -->
        <div class="stats-grid">
          <div v-for="s in stats" :key="s.key" class="stat-card">
            <p class="stat-card-label">{{ tBy(s.label) }}</p>
            <p class="stat-card-value">{{ s.value }}</p>
            <p class="stat-card-trend" :class="s.trend > 0 ? 'up' : 'down'">
              {{ s.trend > 0 ? '+' : '' }}{{ s.trend }}% this month
            </p>
          </div>
        </div>

        <!-- My artworks -->
        <div class="section-block">
          <div class="block-head">
            <h2 class="block-title">{{ t('dashboard.my_artworks') }}</h2>
            <button class="btn btn-ghost" @click="activeTab = 'portfolio'">{{ t('common.view_all') }}</button>
          </div>
          <div class="artworks-table">
            <div class="table-head">
              <span>Artwork</span>
              <span>Category</span>
              <span>Likes</span>
              <span>Views</span>
              <span>Actions</span>
            </div>
            <div v-for="a in myArtworks" :key="a.id" class="table-row">
              <div class="table-artwork-info">
                <img :src="a.image" :alt="a.title" class="table-thumb" />
                <span class="table-title">{{ a.title }}</span>
              </div>
              <span class="tag tag-sm">{{ a.category }}</span>
              <span class="table-cell">♥ {{ a.likes }}</span>
              <span class="table-cell">👁 {{ Math.floor(a.likes * 4.2) }}</span>
              <div class="table-actions">
                <NuxtLink :to="`/artwork/${a.slug}`" class="btn btn-ghost btn-xs">View</NuxtLink>
                <button class="btn btn-ghost btn-xs">Edit</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Portfolio management -->
      <div v-else-if="activeTab === 'portfolio'" class="tab-content">
        <div class="dash-header">
          <h1 class="dash-title">{{ t('dashboard.manage_portfolio') }}</h1>
          <NuxtLink :to="localePath('/dashboard/upload')" class="btn btn-primary">+ Upload</NuxtLink>
        </div>
        <div class="masonry-grid">
          <div v-for="a in myArtworks" :key="a.id" class="portfolio-card">
            <div class="portfolio-img-wrap">
              <RAImage :src="a.image" :alt="a.title" ratio="unset" cover />
              <div class="portfolio-overlay">
                <button class="btn btn-outline btn-xs white">Edit</button>
                <button class="btn btn-ghost btn-xs white">Delete</button>
              </div>
            </div>
            <p class="portfolio-title">{{ a.title }}</p>
            <p class="portfolio-meta">{{ a.category }} · {{ a.year }}</p>
          </div>
        </div>
      </div>

      <!-- AI tools -->
      <div v-else-if="activeTab === 'ai'" class="tab-content">
        <div class="dash-header">
          <h1 class="dash-title">{{ t('dashboard.ai_tools') }}</h1>
        </div>
        <div class="ai-tools-grid">
          <div v-for="tool in aiTools" :key="tool.key" class="ai-tool-card">
            <div class="tool-icon">{{ tool.icon }}</div>
            <h3 class="tool-title">{{ tBy(tool.label) }}</h3>
            <p class="tool-desc">{{ tBy(tool.desc) }}</p>
            <button class="btn btn-outline tool-btn" @click="activeTool = tool.key">
              Try it →
            </button>
          </div>
        </div>

        <!-- Active tool panel -->
        <div v-if="activeTool" class="tool-panel">
          <h3 class="tool-panel-title">{{ tBy(aiTools.find(t => t.key === activeTool)!.label) }}</h3>
          <textarea class="input tool-textarea" placeholder="Paste artwork description or upload an image…" rows="4" />
          <button class="btn btn-primary" @click="runAI">Generate with AI</button>
          <div v-if="aiOutput" class="ai-output">
            <p>{{ aiOutput }}</p>
          </div>
        </div>
      </div>

      <!-- Notifications tab -->
      <div v-else-if="activeTab === 'notifications'" class="tab-content">
        <div class="dash-header">
          <h1 class="dash-title">{{ t('nav.notifications') }}</h1>
          <button class="btn btn-ghost" @click="ui.markAllRead()">Mark all read</button>
        </div>
        <div class="notif-full-list">
          <div
            v-for="n in ui.notifications"
            :key="n.id"
            :class="['notif-full-item', { unread: !n.read }]"
            @click="ui.markRead(n.id)"
          >
            <div class="notif-icon" :class="`type-${n.type}`">
              <span v-if="n.type === 'like'">♥</span>
              <span v-else-if="n.type === 'follow'">+</span>
              <span v-else-if="n.type === 'comment'">💬</span>
              <span v-else>✦</span>
            </div>
            <div>
              <p class="notif-msg-full">{{ n.message }}</p>
              <p class="notif-time-full">{{ new Date(n.createdAt).toLocaleDateString() }}</p>
            </div>
            <div v-if="!n.read" class="notif-dot" />
          </div>
        </div>
      </div>

      <!-- Reading tab -->
      <div v-else-if="activeTab === 'reading'" class="tab-content">
        <div class="dash-header">
          <h1 class="dash-title">{{ t('dashboard.reading') }}</h1>
        </div>
        <div class="reading-grid">
          <div v-for="article in articles" :key="article.id" class="article-card">
            <div class="article-img">
              <img :src="article.cover" :alt="article.title" />
            </div>
            <div class="article-info">
              <span class="tag tag-gold">{{ article.lang }}</span>
              <h3 class="article-title">{{ article.title }}</h3>
              <p class="article-meta">{{ article.author }} · {{ article.readTime }}</p>
              <div class="article-actions">
                <span>♥ {{ article.likes }}</span>
                <span>🔖 {{ article.saves }}</span>
                <button class="btn btn-ghost btn-xs">Read</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ middleware: 'auth' })

import pagesData from '~/assets/json/pages.json'
import { useTBy } from '~/composables/useTBy'

const { t } = useI18n()
const { tBy } = useTBy()
const auth = useAuthStore()
const ui = useUIStore()
const router = useRouter()
const localePath = useLocalePath()

const activeTab = ref('overview')
const activeTool = ref<string | null>(null)
const aiOutput = ref('')

const tabs = [
  { key: 'overview', icon: '◈', label: { en: 'Overview', km: 'ទិដ្ឋភាពទូទៅ' } },
  { key: 'portfolio', icon: '🖼', label: { en: 'Portfolio', km: 'ផតហ្វូលីយ៉ូ' } },
  { key: 'ai', icon: '✦', label: { en: 'AI Studio', km: 'ស្ទូឌីយ៉ូ AI' } },
  { key: 'notifications', icon: '🔔', label: { en: 'Notifications', km: 'ការជូនដំណឹង' } },
  { key: 'reading', icon: '📖', label: { en: 'Reading', km: 'ការអាន' } },
]

const stats = [
  { key: 'views', label: { en: 'Profile Views', km: 'ចំនួនមើល' }, value: '4,821', trend: 12 },
  { key: 'likes', label: { en: 'Total Likes', km: 'ចូលចិត្តសរុប' }, value: '2,340', trend: 8 },
  { key: 'saves', label: { en: 'Saves', km: 'រក្សាទុក' }, value: '718', trend: 5 },
  { key: 'followers', label: { en: 'Followers', km: 'អ្នកតាមដាន' }, value: auth.user?.followersCount.toString() ?? '0', trend: 15 },
]

const myArtworks = pagesData.artworks.filter(a => a.artist.id === 1)

const aiTools = [
  { key: 'caption', icon: '✍️', label: { en: 'Caption Generator', km: 'បង្កើតចំណងជើង' }, desc: { en: 'AI-written captions for your artworks', km: 'ចំណងជើងដែលសរសេរដោយ AI' } },
  { key: 'tags', icon: '🏷️', label: { en: 'Tag Suggester', km: 'ស្នើស្លាក' }, desc: { en: 'Smart tags to boost discoverability', km: 'ស្លាកឆ្លាតដើម្បីបង្កើនការរកឃើញ' } },
  { key: 'style', icon: '🎨', label: { en: 'Style Analysis', km: 'វិភាគស្ទីល' }, desc: { en: 'Identify artistic influences and style', km: 'កំណត់ឥទ្ធិពលសិល្បៈ' } },
  { key: 'seo', icon: '📈', label: { en: 'SEO Description', km: 'ពិពណ៌នា SEO' }, desc: { en: 'Optimised descriptions for search engines', km: 'ការពិពណ៌នាដែលបានធ្វើឱ្យប្រសើរ' } },
  { key: 'upscale', icon: '🔍', label: { en: 'Image Upscale', km: 'ធ្វើឱ្យរូបភាពច្បាស់' }, desc: { en: 'AI-powered resolution enhancement', km: 'ការបង្កើនដំណើររូបភាពដោយ AI' } },
]

const aiResponses: Record<string, string> = {
  caption: 'Bathed in ancient gold, this masterwork transcends time — the Apsara emerges not as a dancer but as a living memory of Khmer civilization, captured through layers of hand-applied gold leaf and luminous acrylic glazes.',
  tags: '#KhmerArt #Apsara #GoldLeaf #CambodianArtist #ContemporaryArt #TraditionalModern #SopheaKhun #RamaGallery #ArtCollector #SoutheastAsianArt',
  style: 'This work exhibits a clear neo-classical Khmer aesthetic, drawing from Angkorian sculptural traditions while incorporating contemporary gestural mark-making. Influences include Vann Nath\'s figurative realism and the gilded Buddhist art of central Thailand.',
  seo: 'This original Cambodian painting by Sophea Khun combines 24k gold leaf with contemporary acrylic techniques to reimagine the sacred Apsara dancer. A museum-quality investment piece representing Cambodia\'s living artistic heritage.',
  upscale: '✓ Image upscaled from 2400×3200px to 9600×12800px (4× enhancement). AI-reconstructed fine details in the gold leaf texture. Ready for print at 300dpi up to 32"×43".',
}

const runAI = async () => {
  aiOutput.value = ''
  await new Promise(r => setTimeout(r, 1200))
  aiOutput.value = aiTools.find(t => t.key === activeTool.value) ? aiResponses[activeTool.value!] : 'Analysis complete.'
}

const articles = [
  { id: 1, title: 'ប្រវត្តិសិល្បៈខ្មែរ', author: 'Ratha Sok', lang: 'KM', cover: 'https://picsum.photos/seed/art1/400/250', readTime: '8 min', likes: 234, saves: 89 },
  { id: 2, title: 'The Rise of Digital Khmer Art', author: 'Pisey Ros', lang: 'EN', cover: 'https://picsum.photos/seed/art2/400/250', readTime: '5 min', likes: 156, saves: 62 },
  { id: 3, title: 'ចិត្រករខ្មែរក្នុងសម័យទំនើប', author: 'Sreyleak Pov', lang: 'KM', cover: 'https://picsum.photos/seed/art3/400/250', readTime: '12 min', likes: 312, saves: 147 },
]

const handleLogout = () => {
  auth.logout()
  router.push(localePath('/'))
}

useSeoMeta({ title: 'Dashboard — RamaGallery' })
</script>

<style scoped lang="scss">
.dashboard {
  display: grid;
  grid-template-columns: 240px 1fr;
  min-height: calc(100vh - var(--header-height));

  @media (max-width: 768px) { grid-template-columns: 1fr; }
}

.sidebar {
  border-right: 1px solid var(--color-border);
  background: var(--color-bg-secondary);
  display: flex;
  flex-direction: column;
  padding: 1.5rem 0;

  @media (max-width: 768px) { display: none; }
}

.sidebar-user {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0 1.25rem 1.5rem;
  border-bottom: 1px solid var(--color-border);
  margin-bottom: 1rem;
}

.sidebar-avatar { width: 44px; height: 44px; border-radius: 50%; object-fit: cover; border: 2px solid var(--color-gold); }
.sidebar-name { font-size: 0.9rem; font-weight: 500; color: var(--color-text-primary); }
.sidebar-role { font-size: 0.75rem; color: var(--color-gold); text-transform: capitalize; }

.sidebar-nav { flex: 1; padding: 0 0.75rem; display: flex; flex-direction: column; gap: 0.125rem; }

.sidebar-link {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem 0.875rem;
  border-radius: 6px;
  font-size: 0.875rem;
  color: var(--color-text-secondary);
  background: transparent;
  border: none;
  cursor: pointer;
  text-decoration: none;
  transition: all var(--transition);
  text-align: left;
  width: 100%;

  &:hover { background: var(--color-bg-card); color: var(--color-text-primary); }
  &.active { background: rgba(200, 149, 28, 0.1); color: var(--color-gold); font-weight: 500; }
  &.danger { color: #e53e3e; &:hover { background: rgba(229, 62, 62, 0.08); } }
}

.link-icon { font-size: 1rem; width: 18px; text-align: center; }

.sidebar-footer { padding: 1rem 0.75rem 0; border-top: 1px solid var(--color-border); margin-top: auto; display: flex; flex-direction: column; gap: 0.125rem; }

.dash-main { padding: 2rem 2.5rem; overflow-y: auto; @media (max-width: 768px) { padding: 1.5rem 1rem; } }

.tab-content { max-width: 1100px; }

.dash-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  margin-bottom: 2rem;
  gap: 1rem;
  flex-wrap: wrap;
}

.dash-title {
  font-family: var(--font-display);
  font-size: 2rem;
  font-weight: 400;
  color: var(--color-text-primary);
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 1rem;
  margin-bottom: 2.5rem;
}

.stat-card {
  background: var(--color-bg-card);
  border: 1px solid var(--color-border);
  border-radius: 8px;
  padding: 1.25rem;
  transition: all var(--transition);

  &:hover { border-color: var(--color-gold); }
}

.stat-card-label { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.12em; color: var(--color-text-muted); margin-bottom: 0.5rem; }
.stat-card-value { font-family: var(--font-display); font-size: 2rem; font-weight: 400; color: var(--color-text-primary); margin-bottom: 0.375rem; }
.stat-card-trend { font-size: 0.75rem; &.up { color: #38a169; } &.down { color: #e53e3e; } }

.section-block { background: var(--color-bg-card); border: 1px solid var(--color-border); border-radius: 8px; overflow: hidden; }
.block-head { display: flex; align-items: center; justify-content: space-between; padding: 1.25rem 1.5rem; border-bottom: 1px solid var(--color-border); }
.block-title { font-family: var(--font-display); font-size: 1.25rem; font-weight: 400; color: var(--color-text-primary); }

.artworks-table { width: 100%; }
.table-head { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr 1fr; gap: 1rem; padding: 0.75rem 1.5rem; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-text-muted); border-bottom: 1px solid var(--color-border); }
.table-row { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr 1fr; gap: 1rem; align-items: center; padding: 0.875rem 1.5rem; border-bottom: 1px solid var(--color-border); transition: background var(--transition); &:last-child { border-bottom: none; } &:hover { background: var(--color-bg-secondary); } }
.table-artwork-info { display: flex; align-items: center; gap: 0.75rem; }
.table-thumb { width: 40px; height: 40px; border-radius: 4px; object-fit: cover; }
.table-title { font-size: 0.875rem; font-weight: 500; color: var(--color-text-primary); }
.table-cell { font-size: 0.875rem; color: var(--color-text-secondary); }
.table-actions { display: flex; gap: 0.375rem; }
.btn-xs { padding: 0.3rem 0.625rem; font-size: 0.75rem; }

.portfolio-card { break-inside: avoid; margin-bottom: 1.5rem; border: 1px solid var(--color-border); border-radius: 4px; overflow: hidden; background: var(--color-bg-card); }
.portfolio-img-wrap { position: relative; min-height: 160px; &:hover .portfolio-overlay { opacity: 1; } }
.portfolio-overlay { position: absolute; inset: 0; background: rgba(10,8,5,0.6); opacity: 0; display: flex; align-items: center; justify-content: center; gap: 0.5rem; transition: opacity 0.3s ease; }
.white { color: #fff; border-color: rgba(255,255,255,0.4); }
.portfolio-title { font-size: 0.9rem; font-weight: 500; padding: 0.75rem 0.875rem 0.25rem; color: var(--color-text-primary); }
.portfolio-meta { font-size: 0.75rem; color: var(--color-text-muted); padding: 0 0.875rem 0.75rem; }

.ai-tools-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
.ai-tool-card { background: var(--color-bg-card); border: 1px solid var(--color-border); border-radius: 8px; padding: 1.5rem; transition: all var(--transition); &:hover { border-color: var(--color-gold); transform: translateY(-2px); } }
.tool-icon { font-size: 1.75rem; margin-bottom: 0.875rem; }
.tool-title { font-family: var(--font-display); font-size: 1.1rem; font-weight: 400; color: var(--color-text-primary); margin-bottom: 0.375rem; }
.tool-desc { font-size: 0.8125rem; color: var(--color-text-secondary); margin-bottom: 1rem; line-height: 1.6; }
.tool-btn { width: 100%; padding: 0.6rem; font-size: 0.8125rem; }

.tool-panel { background: var(--color-bg-card); border: 1px solid var(--color-border); border-radius: 8px; padding: 1.5rem; }
.tool-panel-title { font-family: var(--font-display); font-size: 1.25rem; font-weight: 400; margin-bottom: 1rem; color: var(--color-text-primary); }
.tool-textarea { resize: vertical; font-family: var(--font-sans); margin-bottom: 1rem; border-radius: 8px; }
.ai-output { margin-top: 1.5rem; padding: 1.25rem; background: var(--color-bg-secondary); border-radius: 6px; border-left: 3px solid var(--color-gold); font-size: 0.9rem; color: var(--color-text-secondary); line-height: 1.7; }

.notif-full-list { display: flex; flex-direction: column; gap: 0; border: 1px solid var(--color-border); border-radius: 8px; overflow: hidden; }
.notif-full-item { display: flex; align-items: center; gap: 1rem; padding: 1rem 1.25rem; cursor: pointer; border-bottom: 1px solid var(--color-border); transition: background var(--transition); position: relative; &:last-child { border-bottom: none; } &:hover { background: var(--color-bg-secondary); } &.unread { background: rgba(200, 149, 28, 0.04); } }
.notif-icon { width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.875rem; flex-shrink: 0; &.type-like { background: rgba(229, 62, 62, 0.12); color: #e53e3e; } &.type-follow { background: rgba(56, 161, 105, 0.12); color: #38a169; font-weight: 700; } &.type-comment { background: rgba(49, 130, 206, 0.12); color: #3182ce; } &.type-system { background: rgba(200, 149, 28, 0.12); color: var(--color-gold); } }
.notif-msg-full { font-size: 0.875rem; color: var(--color-text-primary); flex: 1; }
.notif-time-full { font-size: 0.75rem; color: var(--color-text-muted); }
.notif-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--color-gold); }

.reading-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1.25rem; }
.article-card { background: var(--color-bg-card); border: 1px solid var(--color-border); border-radius: 8px; overflow: hidden; transition: all var(--transition); &:hover { border-color: var(--color-gold); transform: translateY(-2px); } }
.article-img { height: 160px; overflow: hidden; img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.4s ease; } &:hover img { transform: scale(1.04); } }
.article-info { padding: 1rem; }
.article-title { font-family: var(--font-display); font-size: 1.1rem; font-weight: 400; color: var(--color-text-primary); margin: 0.375rem 0; }
.article-meta { font-size: 0.8rem; color: var(--color-text-muted); margin-bottom: 0.875rem; }
.article-actions { display: flex; align-items: center; gap: 1rem; font-size: 0.8rem; color: var(--color-text-muted); }
</style>
