<template>
  <div class="auth-page">
    <div class="auth-left">
      <div class="auth-art">
        <img src="https://picsum.photos/seed/register-art/800/1200" alt="Join RamaGallery" class="auth-art-img" draggable="false" />
        <div class="auth-art-overlay" />
        <div class="auth-art-caption">
          <p class="section-label">Join 380+ Artists</p>
          <p class="caption-name">Start your journey</p>
          <p class="caption-work">Build your Cambodian art legacy</p>
        </div>
      </div>
    </div>

    <div class="auth-right">
      <div class="auth-box">
        <NuxtLink to="/" class="auth-logo">
          <span class="logo-icon">ར</span>
          <span>RamaGallery</span>
        </NuxtLink>

        <h1 class="auth-title">{{ t('auth.sign_up') }}</h1>
        <p class="auth-subtitle">Join Cambodia's premier art platform</p>

        <button class="google-btn" @click="registerGoogle">
          <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
          Continue with Google
        </button>

        <div class="divider-or"><span>or</span></div>

        <form class="auth-form" @submit.prevent="handleRegister">
          <div class="fields-row">
            <div class="field">
              <label class="field-label">{{ t('auth.display_name') }}</label>
              <input v-model="form.displayName" type="text" class="input" placeholder="Sophea Khun" required />
            </div>
            <div class="field">
              <label class="field-label">{{ t('auth.username') }}</label>
              <input v-model="form.username" type="text" class="input" placeholder="sophea.art" required />
            </div>
          </div>

          <div class="field">
            <label class="field-label">{{ t('auth.email') }}</label>
            <input v-model="form.email" type="email" class="input" :placeholder="t('auth.email')" required />
          </div>

          <div class="field">
            <label class="field-label">{{ t('auth.phone') }}</label>
            <input v-model="form.phone" type="tel" class="input" placeholder="+855 12 345 678" />
          </div>

          <div class="field">
            <label class="field-label">{{ t('auth.password') }}</label>
            <div class="password-wrap">
              <input v-model="form.password" :type="showPass ? 'text' : 'password'" class="input" placeholder="Min. 8 characters" required minlength="8" />
              <button type="button" class="pass-toggle" @click="showPass = !showPass">{{ showPass ? '🙈' : '👁' }}</button>
            </div>
          </div>

          <!-- Role -->
          <div class="field">
            <label class="field-label">I am joining as</label>
            <div class="role-options">
              <label v-for="r in roles" :key="r.value" :class="['role-opt', { active: form.role === r.value }]">
                <input type="radio" v-model="form.role" :value="r.value" class="sr-only" />
                <span class="role-icon">{{ r.icon }}</span>
                <span class="role-label">{{ r.label }}</span>
              </label>
            </div>
          </div>

          <div class="field terms-field">
            <label class="terms-label">
              <input v-model="form.agreed" type="checkbox" required />
              <span>I agree to the <a href="/terms" target="_blank">Terms of Service</a> and <a href="/privacy" target="_blank">Privacy Policy</a></span>
            </label>
          </div>

          <p v-if="error" class="auth-error">{{ error }}</p>

          <button type="submit" class="btn btn-primary submit-btn" :disabled="auth.isLoading || !form.agreed">
            <span v-if="auth.isLoading" class="spinner" />
            <span v-else>Create account</span>
          </button>
        </form>

        <p class="auth-switch">
          {{ t('auth.have_account') }}
          <NuxtLink :to="localePath('/login')">{{ t('auth.sign_in') }}</NuxtLink>
        </p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ layout: 'default', middleware: 'guest' })

const { t } = useI18n()
const localePath = useLocalePath()
const auth = useAuthStore()
const router = useRouter()

const showPass = ref(false)
const error = ref('')

const form = reactive({
  displayName: '',
  username: '',
  email: '',
  phone: '',
  password: '',
  role: 'artist',
  agreed: false,
})

const roles = [
  { value: 'artist', icon: '🎨', label: 'Artist' },
  { value: 'collector', icon: '🖼️', label: 'Collector' },
  { value: 'visitor', icon: '👤', label: 'Visitor' },
]

const handleRegister = async () => {
  error.value = ''
  const result = await auth.register({ email: form.email, password: form.password, username: form.username })
  if (result.success) {
    if (result.needsProfile) router.push(localePath('/profile'))
    else router.push(localePath('/dashboard'))
  } else {
    error.value = auth.error ?? 'Registration failed'
  }
}

const registerGoogle = async () => {
  await auth.loginWithGoogle()
  router.push(localePath('/profile'))
}

useSeoMeta({ title: 'Join RamaGallery — Create Your Account' })
</script>

<style scoped lang="scss">
.auth-page {
  display: grid;
  grid-template-columns: 1fr 1fr;
  min-height: calc(100vh - var(--header-height));
  @media (max-width: 768px) { grid-template-columns: 1fr; }
}
.auth-left { @media (max-width: 768px) { display: none; } }
.auth-art { position: relative; height: 100%; overflow: hidden; }
.auth-art-img { width: 100%; height: 100%; object-fit: cover; pointer-events: none; }
.auth-art-overlay { position: absolute; inset: 0; background: linear-gradient(to top, rgba(10,8,5,0.8), transparent 50%); }
.auth-art-caption { position: absolute; bottom: 2.5rem; left: 2.5rem; color: #fff; .section-label { color: var(--color-gold); margin-bottom: 0.375rem; } }
.caption-name { font-family: var(--font-display); font-size: 1.5rem; font-weight: 400; margin-bottom: 0.25rem; }
.caption-work { font-size: 0.875rem; opacity: 0.7; }
.auth-right { display: flex; align-items: center; justify-content: center; padding: 3rem 2rem; background: var(--color-bg); }
.auth-box { width: 100%; max-width: 460px; }
.auth-logo { display: flex; align-items: center; gap: 0.5rem; text-decoration: none; margin-bottom: 2rem; font-family: var(--font-display); font-size: 1.25rem; color: var(--color-text-primary); .logo-icon { font-size: 1.5rem; color: var(--color-gold); } }
.auth-title { font-family: var(--font-display); font-size: 2rem; font-weight: 400; color: var(--color-text-primary); margin-bottom: 0.375rem; }
.auth-subtitle { font-size: 0.9rem; color: var(--color-text-muted); margin-bottom: 1.5rem; }
.google-btn { width: 100%; display: flex; align-items: center; justify-content: center; gap: 0.75rem; padding: 0.8rem; background: var(--color-bg-card); border: 1px solid var(--color-border); border-radius: 4px; font-family: var(--font-sans); font-size: 0.9rem; color: var(--color-text-primary); cursor: pointer; transition: all var(--transition); &:hover { border-color: var(--color-border-strong); background: var(--color-bg-secondary); } }
.divider-or { display: flex; align-items: center; gap: 1rem; margin: 1.25rem 0; color: var(--color-text-muted); font-size: 0.8rem; &::before, &::after { content: ''; flex: 1; height: 1px; background: var(--color-border); } }
.auth-form { display: flex; flex-direction: column; gap: 1.125rem; }
.fields-row { display: grid; grid-template-columns: 1fr 1fr; gap: 0.875rem; }
.field { display: flex; flex-direction: column; gap: 0.5rem; }
.field-label { font-size: 0.8125rem; font-weight: 500; color: var(--color-text-secondary); }
.password-wrap { position: relative; display: flex; }
.pass-toggle { position: absolute; right: 0.75rem; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer; font-size: 0.9rem; }

.role-options { display: flex; gap: 0.625rem; }
.role-opt { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 0.375rem; padding: 0.875rem 0.5rem; border: 1px solid var(--color-border); border-radius: 6px; cursor: pointer; transition: all var(--transition); &:hover { border-color: var(--color-gold); } &.active { border-color: var(--color-gold); background: rgba(200, 149, 28, 0.08); } }
.role-icon { font-size: 1.25rem; }
.role-label { font-size: 0.75rem; color: var(--color-text-secondary); }
.sr-only { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0,0,0,0); }

.terms-field { }
.terms-label { display: flex; align-items: flex-start; gap: 0.625rem; font-size: 0.8125rem; color: var(--color-text-secondary); cursor: pointer; a { color: var(--color-gold); text-decoration: none; } input { margin-top: 1px; accent-color: var(--color-gold); } }

.auth-error { font-size: 0.875rem; color: #e53e3e; }
.submit-btn { width: 100%; padding: 0.875rem; font-size: 0.9375rem; }
.auth-switch { margin-top: 1.5rem; font-size: 0.875rem; color: var(--color-text-muted); text-align: center; a { color: var(--color-gold); text-decoration: none; } }
.spinner { width: 18px; height: 18px; border: 2px solid rgba(255,255,255,0.3); border-top-color: #fff; border-radius: 50%; animation: spin 0.7s linear infinite; display: inline-block; }
@keyframes spin { to { transform: rotate(360deg); } }
</style>
