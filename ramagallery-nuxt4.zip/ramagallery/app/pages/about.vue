<template>
  <div class="about-page">

    <!-- ── Hero ──────────────────────────────── -->
    <section id="about" class="about-hero">
      <div class="container">
        <p class="section-label animate-on-scroll">{{ tBy({ en: 'Our Story', km: 'រឿងរ៉ាវរបស់យើង' }) }}</p>
        <h1 class="about-title animate-on-scroll delay-1">
          {{ tBy({ en: 'Art Deserves', km: 'សិល្បៈ' }) }}
          <span class="gold-text italic">{{ tBy({ en: 'a Home.', km: 'ត្រូវការទីស្នាក់' }) }}</span>
        </h1>
        <p class="about-lead animate-on-scroll delay-2">
          {{ tBy({ en: 'RamaGallery was born from a simple belief: Cambodian art is extraordinary, and the world should know it.', km: 'RamaGallery កើតឡើងពីជំនឿសាមញ្ញ៖ សិល្បៈខ្មែរគឺពិសេស ហើយពិភពលោកគួរតែដឹង។' }) }}
        </p>
      </div>
      <div class="about-hero-img-row">
        <div class="hero-img animate-on-scroll delay-1"><RAImage src="https://picsum.photos/seed/about1/500/700" aspect="portrait" :watermark="false" /></div>
        <div class="hero-img tall animate-on-scroll delay-2"><RAImage src="https://picsum.photos/seed/about2/500/800" aspect="portrait" :watermark="false" /></div>
        <div class="hero-img animate-on-scroll delay-3"><RAImage src="https://picsum.photos/seed/about3/500/650" aspect="portrait" :watermark="false" /></div>
      </div>
    </section>

    <!-- ── Stats ─────────────────────────────── -->
    <section id="about-stats" class="stats-band">
      <div class="container stats-grid">
        <div v-for="(s, i) in stats" :key="s.label.en" class="stat-item animate-on-scroll" :class="`delay-${i+1}`">
          <span class="stat-num gold-text">{{ s.val }}</span>
          <span class="stat-lbl">{{ tBy(s.label) }}</span>
        </div>
      </div>
    </section>

    <!-- ── Mission ───────────────────────────── -->
    <section id="mission" class="section mission-section">
      <div class="container mission-grid">
        <div class="mission-media animate-on-scroll slide-right">
          <RAImage src="https://picsum.photos/seed/about4/600/700" aspect="portrait" :watermark="false" />
          <div class="mission-media-badge">
            <span class="badge-num gold-text">2022</span>
            <span class="badge-lbl">{{ tBy({ en: 'Founded', km: 'បង្កើត' }) }}</span>
          </div>
        </div>
        <div class="mission-content animate-on-scroll slide-left">
          <p class="section-label">{{ tBy({ en: 'Mission', km: 'បេសកកម្ម' }) }}</p>
          <h2 class="mission-title">{{ tBy({ en: 'Bridging Tradition and Tomorrow', km: 'ភ្ជាប់ប្រពៃណីទៅអនាគត' }) }}</h2>
          <div class="mission-body">
            <p>{{ tBy({ en: 'From the intricate stone carvings of Angkor to contemporary digital expression, Cambodian artists have always told stories that transcend borders. We built RamaGallery to give those stories a permanent, beautiful, and protected home on the internet.', km: 'ពីការចម្លាក់ថ្មដ៏ស្មុគស្មាញនៃអង្គរ ដល់ការបញ្ចេញមតិឌីជីថលសម័យទំនើប វិចិត្រករខ្មែរតែងតែរៀបរាប់រឿងរ៉ាវ។' }) }}</p>
            <p>{{ tBy({ en: 'We are more than a platform — we are a movement to preserve, celebrate, and economically empower the artists who define Cambodian culture.', km: 'យើងជាច្រើនជាងវេទិកា — យើងជាចលនាដើម្បីការពារ និងផ្តល់力量ដល់វិចិត្រករ' }) }}</p>
          </div>
          <div class="mission-pillars">
            <div v-for="p in pillars" :key="p.title.en" class="pillar">
              <span class="pillar-icon">{{ p.icon }}</span>
              <div>
                <strong class="pillar-title">{{ tBy(p.title) }}</strong>
                <p class="pillar-desc">{{ tBy(p.desc) }}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ── Values ────────────────────────────── -->
    <section id="values" class="section values-section">
      <div class="container">
        <div class="section-head animate-on-scroll">
          <p class="section-label">{{ tBy({ en: 'What We Stand For', km: 'អ្វីដែលយើងតស៊ូ' }) }}</p>
          <h2 class="section-title animate-on-scroll delay-1">{{ tBy({ en: 'Our Values', km: 'គុណតម្លៃ' }) }}</h2>
        </div>
        <div class="values-grid">
          <div v-for="(v, i) in values" :key="v.title.en" class="value-card card animate-on-scroll" :class="`delay-${i+1}`">
            <div class="vc-icon">{{ v.icon }}</div>
            <h3 class="vc-title">{{ tBy(v.title) }}</h3>
            <p class="vc-desc">{{ tBy(v.desc) }}</p>
          </div>
        </div>
      </div>
    </section>

    <!-- ── Team ──────────────────────────────── -->
    <section id="team" class="section team-section">
      <div class="container">
        <div class="section-head animate-on-scroll">
          <p class="section-label">{{ tBy({ en: 'The People', km: 'ក្រុមការងារ' }) }}</p>
          <h2 class="section-title animate-on-scroll delay-1">{{ tBy({ en: 'Our Team', km: 'ក្រុមការងាររបស់យើង' }) }}</h2>
        </div>
        <div class="team-grid">
          <div v-for="(m, i) in teams" :key="m.id" class="team-card card animate-on-scroll" :class="`delay-${i+1}`">
            <div class="tc-img-wrap">
              <img :src="m.avatar" :alt="m.name" class="tc-avatar" />
              <div class="tc-img-border" />
            </div>
            <h3 class="tc-name">{{ m.name }}</h3>
            <p class="tc-role">{{ tBy(m.role) }}</p>
            <p class="tc-bio">{{ tBy(m.bio) }}</p>
          </div>
        </div>
      </div>
    </section>

    <!-- ── CTA ───────────────────────────────── -->
    <section id="about-cta" class="cta-band">
      <div class="container">
        <div class="cta-inner animate-on-scroll">
          <p class="section-label">{{ tBy({ en: 'Join Us', km: 'ចូលជាមួយ' }) }}</p>
          <h2 class="cta-title">{{ tBy({ en: 'Your art belongs here.', km: 'សិល្បៈរបស់អ្នកជារបស់ទីនេះ' }) }}</h2>
          <div class="cta-actions">
            <NuxtLink to="/register" class="btn btn-primary">{{ tBy({ en: 'Start Your Portfolio', km: 'ចាប់ផ្តើមផតហ្វូលីយ៉ូ' }) }}</NuxtLink>
            <NuxtLink to="/contact" class="btn btn-outline cta-outline-light">{{ tBy({ en: 'Get in Touch', km: 'ទំនាក់ទំនង' }) }}</NuxtLink>
          </div>
        </div>
      </div>
    </section>

  </div>
</template>

<script setup lang="ts">
import pagesData from '~/assets/json/pages.json'
import { useTBy } from '~/composables/useTBy'

const { tBy } = useTBy()
useScrollAnimation()

const teams = pagesData.teams
const stats = [
  { val: '2,400+', label: { en: 'Artworks', km: 'ស្នាដៃ' } },
  { val: '180+',   label: { en: 'Artists',  km: 'វិចិត្រករ' } },
  { val: '45+',    label: { en: 'Countries', km: 'ប្រទេស' } },
  { val: '12k+',   label: { en: 'Collectors', km: 'អ្នកប្រមូល' } },
]

const pillars = [
  { icon: '🏛️', title: { en: 'Preserve', km: 'ការអភិរក្ស' }, desc: { en: 'Ancient traditions kept alive through digital stewardship.', km: 'ប្រពៃណីបុរាណត្រូវបានថែទាំ' } },
  { icon: '🌏', title: { en: 'Connect', km: 'ការភ្ជាប់' }, desc: { en: 'Cambodian creators meeting global collectors.', km: 'អ្នកបង្កើតខ្មែរជួបអ្នកប្រមូលពិភពលោក' } },
  { icon: '💡', title: { en: 'Empower', km: 'ផ្តល់力量' }, desc: { en: 'AI and technology in service of artistic independence.', km: 'AI និងបច្ចេកវិទ្យាដើម្បីឯករាជ្យភាពសិល្បៈ' } },
]

const values = [
  { icon: '🏛️', title: { en: 'Cultural Preservation', km: 'ការអភិរក្សវប្បធម៌' }, desc: { en: 'We protect and celebrate Cambodia\'s artistic heritage — from ancient traditions to emerging voices.', km: 'យើងការពារ និងអបអរសំបូរបែបសិល្បៈខ្មែរ' } },
  { icon: '🤝', title: { en: 'Artist Empowerment', km: 'ការផ្តល់力量' }, desc: { en: 'Every tool we build puts more economic control and creative freedom in artists\' hands.', km: 'ឧបករណ៍ដែលយើងបង្កើតដាក់ Control ដល់វិចិត្រករ' } },
  { icon: '🌏', title: { en: 'Global Reach', km: 'ការឈានដល់ពិភពលោក' }, desc: { en: 'We connect Cambodian creators with collectors, galleries, and art lovers worldwide.', km: 'យើងភ្ជាប់ Creators ខ្មែរជាមួយអ្នកទូទាំងពិភពលោក' } },
  { icon: '🛡️', title: { en: 'Integrity & Safety', km: 'ភាពស្មោះ' }, desc: { en: 'We protect artists\' intellectual property with the most advanced image security available.', km: 'យើងការពារកម្មសិទ្ធិបញ្ញារបស់វិចិត្រករ' } },
]

useSeoMeta({ title: 'About — RamaGallery', description: 'The story behind Cambodia\'s premier art platform.' })
</script>

<style scoped lang="scss">
// Hero
.about-hero { padding: 6rem 0 0; overflow: hidden; background: var(--color-bg-secondary); }
.about-title { font-size: clamp(3rem, 8vw, 6rem); max-width: 760px; margin: 0.5rem auto 1.5rem; text-align: center; line-height: 1.05; }
.about-lead { font-size: clamp(0.95rem, 2vw, 1.1rem); color: var(--color-text-secondary); max-width: 560px; margin: 0 auto 3.5rem; line-height: 1.8; text-align: center; }

.about-hero-img-row { display: flex; align-items: flex-end; gap: 0.875rem; max-width: var(--container-max); margin: 0 auto; padding: 0 var(--container-pad); }
.hero-img { flex: 1; overflow: hidden; border-radius: var(--radius-md) var(--radius-md) 0 0; &.tall { flex: 1.3; } }

// Stats
.stats-band { background: var(--color-text-primary); padding: 3rem 0; .dark & { background: var(--color-bg-tertiary); } }
.stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 2rem; text-align: center; @media (max-width: 640px) { grid-template-columns: repeat(2, 1fr); } }
.stat-item { display: flex; flex-direction: column; gap: 0.4rem; }
.stat-num { font-family: var(--font-display); font-size: clamp(2.5rem, 5vw, 3.5rem); line-height: 1; }
.stat-lbl { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.2em; color: rgba(240,236,228,0.5); .dark & { color: var(--color-text-muted); } }

// Mission
.mission-section { }
.mission-grid { display: grid; grid-template-columns: 1fr 1.4fr; gap: 5rem; align-items: center; @media (max-width: 900px) { grid-template-columns: 1fr; gap: 2.5rem; } }
.mission-media { position: relative; }
.mission-media-badge { position: absolute; bottom: -1rem; right: -1rem; background: var(--color-gold); color: #fff; padding: 1.25rem 1.5rem; border-radius: var(--radius-md); text-align: center; box-shadow: var(--shadow-gold); }
.badge-num { font-family: var(--font-display); font-size: 2rem; color: #fff; display: block; }
.badge-lbl { font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.15em; opacity: 0.8; }
.mission-title { font-size: clamp(1.75rem, 4vw, 2.75rem); margin: 0.75rem 0 1.5rem; }
.mission-body { display: flex; flex-direction: column; gap: 1rem; margin-bottom: 2rem; p { font-size: 0.95rem; color: var(--color-text-secondary); line-height: 1.8; } }
.mission-pillars { display: flex; flex-direction: column; gap: 1.25rem; }
.pillar { display: flex; align-items: flex-start; gap: 1rem; }
.pillar-icon { font-size: 1.5rem; flex-shrink: 0; }
.pillar-title { font-size: 0.9rem; font-weight: 600; display: block; color: var(--color-text-primary); margin-bottom: 0.25rem; }
.pillar-desc { font-size: 0.83rem; color: var(--color-text-secondary); }

// Values
.values-section { background: var(--color-bg-secondary); }
.section-head { margin-bottom: 3rem; }
.section-title { font-size: clamp(2rem, 5vw, 3.5rem); margin-top: 0.5rem; }
.values-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 1.25rem; }
.value-card { padding: 2rem; transition: all var(--transition); &:hover { transform: translateY(-4px); border-color: var(--color-gold); box-shadow: var(--shadow-gold); } }
.vc-icon { font-size: 2rem; margin-bottom: 1.25rem; }
.vc-title { font-family: var(--font-display); font-size: 1.2rem; margin-bottom: 0.75rem; }
.vc-desc { font-size: 0.875rem; color: var(--color-text-secondary); line-height: 1.7; }

// Team
.team-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1.25rem; }
.team-card { padding: 2rem; text-align: center; transition: all var(--transition); &:hover { transform: translateY(-3px); border-color: var(--color-gold); } }
.tc-img-wrap { position: relative; display: inline-block; margin-bottom: 1.25rem; }
.tc-avatar { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid var(--color-gold); }
.tc-img-border { position: absolute; inset: -4px; border-radius: 50%; border: 1px solid var(--color-border); }
.tc-name { font-family: var(--font-display); font-size: 1.15rem; margin-bottom: 0.375rem; }
.tc-role { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.12em; color: var(--color-gold); margin-bottom: 0.875rem; }
.tc-bio { font-size: 0.83rem; color: var(--color-text-secondary); line-height: 1.6; }

// CTA band
.cta-band { background: var(--color-text-primary); padding: 6rem 2rem; .dark & { background: var(--color-bg-secondary); } }
.cta-inner { text-align: center; max-width: 600px; margin: 0 auto; .section-label { color: var(--color-gold); } }
.cta-title { font-family: var(--font-display); font-size: clamp(2.5rem, 6vw, 4rem); color: var(--color-bg); margin: 1rem 0 2.5rem; line-height: 1.1; .dark & { color: var(--color-text-primary); } }
.cta-actions { display: flex; align-items: center; justify-content: center; gap: 1rem; flex-wrap: wrap; }
.cta-outline-light { border-color: rgba(240,236,228,0.3); color: var(--color-bg); &:hover { border-color: var(--color-gold); color: var(--color-gold); } .dark & { border-color: var(--color-border-strong); color: var(--color-text-primary); } }

.italic { font-style: italic; }
</style>
