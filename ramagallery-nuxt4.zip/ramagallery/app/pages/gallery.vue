<template>
  <div class="gallery-page">

    <!-- ── Page Hero ─────────────────────────── -->
    <section id="gallery" class="gallery-hero">
      <div class="container">
        <p class="section-label animate-on-scroll">{{ tBy({ en: 'Browse & Collect', km: 'រុករក និងប្រមូល' }) }}</p>
        <h1 class="gallery-hero-title animate-on-scroll delay-1">
          {{ tBy({ en: 'The Gallery', km: 'វិចិត្រសាល' }) }}
        </h1>
        <p class="gallery-hero-subtitle animate-on-scroll delay-2">
          {{ tBy({ en: 'Every artwork tells a Cambodian story', km: 'ស្នាដៃទាំងអស់ប្រាប់រឿងរ៉ាវខ្មែរ' }) }}
        </p>
      </div>
      <div class="hero-divider divider-gold animate-on-scroll delay-3" />
    </section>

    <!-- ── Filters ─────────────────────────────── -->
    <section id="gallery-filters" class="gallery-filters-bar">
      <div class="container filters-inner">
        <div class="filter-chips">
          <button
            v-for="cat in categories"
            :key="cat.value"
            class="filter-chip"
            :class="{ active: activeCategory === cat.value }"
            @click="setCategory(cat.value)"
          >
            {{ tBy(cat.label) }}
          </button>
        </div>
        <div class="sort-row">
          <select v-model="sortBy" class="sort-select">
            <option value="newest">{{ t('gallery.sort_newest') }}</option>
            <option value="popular">{{ t('gallery.sort_popular') }}</option>
            <option value="price">{{ t('gallery.sort_price_asc') }}</option>
          </select>
          <div class="view-toggle">
            <button :class="{ active: viewMode === 'masonry' }" @click="viewMode = 'masonry'" :data-tooltip="tBy({ en: 'Masonry', km: 'ជាជួរ' })">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="3" width="7" height="11" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="18" width="7" height="3" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
            </button>
            <button :class="{ active: viewMode === 'grid' }" @click="viewMode = 'grid'" :data-tooltip="tBy({ en: 'Grid', km: 'ក្រឡាចត្រង្គ' })">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
            </button>
          </div>
        </div>
      </div>
    </section>

    <!-- ── Artwork Grid ────────────────────────── -->
    <section class="section gallery-main">
      <div class="container">
        <p class="result-count animate-on-scroll">
          {{ filteredArtworks.length }} {{ tBy({ en: 'artworks', km: 'ស្នាដៃ' }) }}
        </p>

        <!-- Masonry mode -->
        <div v-if="viewMode === 'masonry'" class="masonry-grid">
          <div
            v-for="(aw, i) in visibleArtworks"
            :key="aw.id"
            class="masonry-item animate-on-scroll"
            :class="`delay-${Math.min(i % 6 + 1, 8)}`"
          >
            <NuxtLink :to="`/artwork/${aw.slug}`" class="artwork-card card">
              <div class="artwork-img-wrap">
                <RAImage
                  :src="aw.image"
                  :alt="aw.title"
                  aspect="auto"
                  watermark
                />
                <div class="artwork-hover-overlay">
                  <div class="overlay-actions">
                    <button class="overlay-btn" @click.prevent="toggleLike(aw.id)" :data-tooltip="t('artwork.likes')">
                      <svg width="18" height="18" viewBox="0 0 24 24" :fill="likedIds.has(aw.id) ? 'currentColor' : 'none'" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                    </button>
                    <button class="overlay-btn" @click.prevent="toggleSave(aw.id)" :data-tooltip="t('artwork.saves')">
                      <svg width="18" height="18" viewBox="0 0 24 24" :fill="savedIds.has(aw.id) ? 'currentColor' : 'none'" stroke="currentColor" stroke-width="2"><path d="m19 21-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/></svg>
                    </button>
                  </div>
                </div>
              </div>
              <div class="artwork-meta">
                <div class="artwork-meta-top">
                  <span class="tag tag-gold">{{ tBy({ en: aw.category, km: aw.category }) }}</span>
                  <span class="artwork-year">{{ aw.year }}</span>
                </div>
                <h3 class="artwork-title">{{ tBy({ en: aw.title, km: aw.title_km }) }}</h3>
                <div class="artwork-artist-row">
                  <img :src="aw.artist.avatar" :alt="aw.artist.name" class="artist-mini-avatar" />
                  <span class="artist-mini-name">{{ aw.artist.name }}</span>
                </div>
                <div class="artwork-stats">
                  <span>♥ {{ likedIds.has(aw.id) ? aw.likes + 1 : aw.likes }}</span>
                  <span class="artwork-price">${{ aw.price.toLocaleString() }}</span>
                </div>
              </div>
            </NuxtLink>
          </div>
        </div>

        <!-- Uniform grid mode -->
        <div v-else class="uniform-grid">
          <NuxtLink
            v-for="(aw, i) in visibleArtworks"
            :key="aw.id"
            :to="`/artwork/${aw.slug}`"
            class="grid-card card animate-on-scroll"
            :class="`delay-${Math.min(i % 6 + 1, 8)}`"
          >
            <RAImage :src="aw.image" :alt="aw.title" aspect="landscape" watermark />
            <div class="grid-card-meta">
              <h3 class="artwork-title">{{ tBy({ en: aw.title, km: aw.title_km }) }}</h3>
              <p class="artist-name-sm">{{ aw.artist.name }}</p>
              <p class="artwork-price">${{ aw.price.toLocaleString() }}</p>
            </div>
          </NuxtLink>
        </div>

        <!-- Load more -->
        <div v-if="visibleCount < filteredArtworks.length" class="load-more-wrap animate-on-scroll">
          <button class="btn btn-outline load-more-btn" @click="loadMore">
            {{ t('gallery.load_more') }}
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12l7 7 7-7"/></svg>
          </button>
        </div>

        <!-- Empty state -->
        <div v-if="filteredArtworks.length === 0" class="empty-state animate-on-scroll">
          <div class="empty-icon">🖼️</div>
          <h3>{{ tBy({ en: 'No artworks found', km: 'រកមិនឃើញស្នាដៃ' }) }}</h3>
          <p>{{ tBy({ en: 'Try a different category or filter', km: 'សាកល្បងប្រភេទផ្សេង' }) }}</p>
          <button class="btn btn-outline" @click="activeCategory = 'all'">{{ tBy({ en: 'Show all', km: 'បង្ហាញទាំងអស់' }) }}</button>
        </div>
      </div>
    </section>

  </div>
</template>

<script setup lang="ts">
import pagesData from '~/assets/json/pages.json'
import { useTBy } from '~/composables/useTBy'

const { t } = useI18n()
const { tBy } = useTBy()
const auth = useAuthStore()
useScrollAnimation()

const activeCategory = ref('all')
const sortBy = ref('newest')
const viewMode = ref<'masonry' | 'grid'>('masonry')
const visibleCount = ref(8)
const likedIds = ref(new Set<number>())
const savedIds = ref(new Set<number>())

const categories = [
  { value: 'all',          label: { en: 'All',           km: 'ទាំងអស់' } },
  { value: 'painting',     label: { en: 'Painting',      km: 'គំនូរ' } },
  { value: 'sculpture',    label: { en: 'Sculpture',     km: 'ចម្លាក់' } },
  { value: 'digital',      label: { en: 'Digital',       km: 'ឌីជីថល' } },
  { value: 'photography',  label: { en: 'Photography',   km: 'ថតរូប' } },
  { value: 'traditional',  label: { en: 'Traditional',   km: 'បុរាណ' } },
]

const filteredArtworks = computed(() => {
  let list = pagesData.artworks
  if (activeCategory.value !== 'all') list = list.filter(a => a.category === activeCategory.value)
  if (sortBy.value === 'popular')  list = [...list].sort((a, b) => b.likes - a.likes)
  if (sortBy.value === 'price')    list = [...list].sort((a, b) => a.price - b.price)
  if (sortBy.value === 'newest')   list = [...list].sort((a, b) => b.year - a.year)
  return list
})

const visibleArtworks = computed(() => filteredArtworks.value.slice(0, visibleCount.value))

function setCategory(cat: string) {
  activeCategory.value = cat
  visibleCount.value = 8
}

function loadMore() { visibleCount.value += 8 }

function toggleLike(id: number) {
  if (!auth.isLoggedIn) { navigateTo('/login'); return }
  likedIds.value.has(id) ? likedIds.value.delete(id) : likedIds.value.add(id)
}

function toggleSave(id: number) {
  if (!auth.isLoggedIn) { navigateTo('/login'); return }
  savedIds.value.has(id) ? savedIds.value.delete(id) : savedIds.value.add(id)
}

useSeoMeta({
  title: 'Gallery — RamaGallery',
  description: 'Browse thousands of Cambodian artworks — paintings, photography, sculpture, digital art.',
})
</script>

<style scoped lang="scss">
// ── Hero ──────────────────────────────────────
.gallery-hero {
  padding: 5.5rem 0 3.5rem;
  text-align: center;
  background: linear-gradient(180deg, var(--color-bg-secondary) 0%, var(--color-bg) 100%);
  border-bottom: 1px solid var(--color-border);
  position: relative;
  overflow: hidden;

  &::before {
    content: '';
    position: absolute;
    inset: 0;
    background: radial-gradient(ellipse at 60% 0%, rgba(200,149,28,0.06) 0%, transparent 65%);
    pointer-events: none;
  }
}

.gallery-hero-title {
  font-size: clamp(2.5rem, 7vw, 5rem);
  margin-bottom: 0.75rem;
}

.gallery-hero-subtitle {
  font-size: clamp(0.9rem, 2vw, 1.1rem);
  color: var(--color-text-secondary);
  max-width: 420px;
  margin: 0 auto;
}

.hero-divider {
  margin: 2.5rem auto 0;
}

// ── Filters bar ───────────────────────────────
.gallery-filters-bar {
  position: sticky;
  top: var(--header-height);
  z-index: 50;
  background: var(--color-bg-overlay);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  border-bottom: 1px solid var(--color-border);
  padding: 0.875rem 0;
}

.filters-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  flex-wrap: wrap;
}

.filter-chips {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  flex-wrap: wrap;
}

.filter-chip {
  padding: 0.4rem 1rem;
  border-radius: 20px;
  border: 1px solid var(--color-border);
  background: transparent;
  color: var(--color-text-secondary);
  font-family: var(--font-sans);
  font-size: 0.78rem;
  font-weight: 500;
  cursor: pointer;
  transition: all var(--transition);

  &:hover { border-color: var(--color-gold); color: var(--color-gold); }
  &.active {
    background: var(--color-gold);
    border-color: var(--color-gold);
    color: #fff;
  }
}

.sort-row {
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.sort-select {
  padding: 0.4rem 0.875rem;
  background: var(--color-bg-secondary);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  color: var(--color-text-secondary);
  font-size: 0.8rem;
  font-family: var(--font-sans);
  cursor: pointer;
  transition: border-color var(--transition);

  &:focus { outline: none; border-color: var(--color-gold); }
}

.view-toggle {
  display: flex;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  overflow: hidden;

  button {
    padding: 0.45rem 0.75rem;
    background: transparent;
    border: none;
    color: var(--color-text-muted);
    cursor: pointer;
    transition: all var(--transition);

    &.active { background: var(--color-gold); color: #fff; }
    &:hover:not(.active) { background: var(--color-bg-secondary); color: var(--color-text-primary); }
  }
}

// ── Gallery Main ──────────────────────────────
.gallery-main { padding-top: 2.5rem; }

.result-count {
  font-size: 0.8rem;
  color: var(--color-text-muted);
  letter-spacing: 0.05em;
  margin-bottom: 2rem;
}

// ── Artwork card ──────────────────────────────
.artwork-card {
  display: block;
  text-decoration: none;
  overflow: hidden;
  border-radius: var(--radius-md);

  &:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-lg);
    border-color: var(--color-border-strong);

    .artwork-hover-overlay { opacity: 1; }
    .artwork-img-wrap :deep(.ra-img) { transform: scale(1.04); }
  }
}

.artwork-img-wrap {
  position: relative;
  overflow: hidden;
}

.artwork-hover-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(to top, rgba(0,0,0,0.55) 0%, transparent 60%);
  display: flex;
  align-items: flex-end;
  justify-content: flex-end;
  padding: 0.875rem;
  opacity: 0;
  transition: opacity 0.3s ease;
  z-index: 5;
}

.overlay-actions {
  display: flex;
  gap: 0.5rem;
}

.overlay-btn {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  border: none;
  background: rgba(255,255,255,0.15);
  backdrop-filter: blur(8px);
  color: #fff;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all var(--transition);

  &:hover { background: rgba(255,255,255,0.3); transform: scale(1.1); }
}

.artwork-meta {
  padding: 1rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.artwork-meta-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.artwork-year {
  font-size: 0.7rem;
  color: var(--color-text-muted);
  letter-spacing: 0.08em;
}

.artwork-title {
  font-family: var(--font-display);
  font-size: 1rem;
  font-weight: 400;
  color: var(--color-text-primary);
  line-height: 1.3;
  transition: color var(--transition);

  .artwork-card:hover & { color: var(--color-gold); }
}

.artwork-artist-row {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.artist-mini-avatar {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  object-fit: cover;
  border: 1px solid var(--color-border);
}

.artist-mini-name {
  font-size: 0.78rem;
  color: var(--color-text-muted);
}

.artwork-stats {
  display: flex;
  justify-content: space-between;
  font-size: 0.78rem;
  color: var(--color-text-muted);
  padding-top: 0.5rem;
  border-top: 1px solid var(--color-border);
}

.artwork-price { color: var(--color-gold); font-weight: 500; }

// ── Uniform grid ──────────────────────────────
.uniform-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 1.25rem;
}

.grid-card {
  display: block;
  text-decoration: none;
  overflow: hidden;
  transition: all var(--transition);

  &:hover { transform: translateY(-3px); box-shadow: var(--shadow-md); }
}

.grid-card-meta {
  padding: 1rem;

  h3 { font-family: var(--font-display); font-size: 1rem; margin-bottom: 0.25rem; }
}

.artist-name-sm { font-size: 0.8rem; color: var(--color-text-muted); margin-bottom: 0.25rem; }

// ── Load more ─────────────────────────────────
.load-more-wrap { text-align: center; padding-top: 3rem; }
.load-more-btn { min-width: 200px; }

// ── Empty state ───────────────────────────────
.empty-state {
  text-align: center;
  padding: 5rem 2rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;

  .empty-icon { font-size: 3rem; }
  h3 { font-family: var(--font-display); font-size: 1.5rem; }
  p { color: var(--color-text-secondary); }
}
</style>
