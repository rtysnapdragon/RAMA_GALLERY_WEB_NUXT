<template>
  <div class="services-page">

    <!-- ── Hero ─────────────────────────── -->
    <section id="services" class="services-hero">
      <div class="container">
        <p class="section-label animate-on-scroll">{{ tBy({ en: 'What We Offer', km: 'អ្វីដែលយើងផ្តល់' }) }}</p>
        <h1 class="services-title animate-on-scroll delay-1">{{ tBy({ en: 'Built for Artists', km: 'សាងសង់សម្រាប់វិចិត្រករ' }) }}</h1>
        <p class="services-sub animate-on-scroll delay-2">{{ tBy({ en: 'Everything you need to share, protect, and monetise your art — in Khmer and English', km: 'ឧបករណ៍ទាំងអស់ដើម្បីចែករំលែក ការពារ និងធ្វើប្រាក់ចំណេញ' }) }}</p>
        <div class="hero-ctas animate-on-scroll delay-3">
          <NuxtLink to="/register" class="btn btn-primary">{{ tBy({ en: 'Start Free', km: 'ចាប់ផ្តើមដោយឥតគិតថ្លៃ' }) }}</NuxtLink>
          <a href="#pricing" class="btn btn-outline">{{ tBy({ en: 'See Pricing', km: 'មើលតម្លៃ' }) }}</a>
        </div>
      </div>
    </section>

    <!-- ── Services grid ─────────────────── -->
    <section id="features" class="section features-section">
      <div class="container">
        <div class="section-head animate-on-scroll">
          <p class="section-label">{{ tBy({ en: 'Core Features', km: 'មុខងារស្នូល' }) }}</p>
          <h2 class="section-title animate-on-scroll delay-1">{{ tBy({ en: 'Platform Features', km: 'មុខងារវេទិកា' }) }}</h2>
        </div>
        <div class="services-grid">
          <div v-for="(svc, i) in services" :key="svc.id" class="svc-card card animate-on-scroll" :class="`delay-${(i%6)+1}`">
            <div class="svc-icon-wrap">
              <span class="svc-icon">{{ svc.icon }}</span>
            </div>
            <h3 class="svc-title">{{ tBy(svc.title) }}</h3>
            <p class="svc-desc">{{ tBy(svc.description) }}</p>
            <div class="svc-arrow">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ── AI spotlight ────────────────── -->
    <section id="ai-studio" class="section ai-section">
      <div class="container ai-grid">
        <div class="ai-content animate-on-scroll slide-right">
          <p class="section-label">{{ tBy({ en: 'AI Powered', km: 'ขับ​ Movement​ ដោយ AI' }) }}</p>
          <h2 class="ai-title">{{ tBy({ en: 'RamaAI Studio', km: 'ស្ទូឌីយ៉ូ RamaAI' }) }}</h2>
          <p class="ai-desc">{{ tBy({ en: 'Let artificial intelligence do the heavy lifting — generate captions, suggest tags, analyse your style, write SEO descriptions, and upscale your images. All in Khmer and English.', km: 'ឱ្យ AI ធ្វើការងារ — បង្កើតចំណងជើង ស្នើស្លាក វិភាគស្ទីល សរសេរ SEO និងធ្វើឱ្យរូបភាពច្បាស់ ជាភាសាខ្មែរ និងអង់គ្លេស' }) }}</p>
          <div class="ai-features">
            <div v-for="f in aiFeatures" :key="f.label.en" class="ai-feat">
              <span class="af-icon">{{ f.icon }}</span>
              <div>
                <strong class="af-label">{{ tBy(f.label) }}</strong>
                <p class="af-desc">{{ tBy(f.desc) }}</p>
              </div>
            </div>
          </div>
          <NuxtLink to="/dashboard/ai" class="btn btn-primary mt-cta">{{ tBy({ en: 'Try AI Studio', km: 'សាកល្បងស្ទូឌីយ៉ូ AI' }) }}</NuxtLink>
        </div>
        <div class="ai-visual animate-on-scroll slide-left">
          <div class="ai-mockup glass">
            <div class="am-header">
              <div class="am-avatar">ར</div>
              <div>
                <p class="am-name">RamaAI</p>
                <p class="am-status"><span class="status-dot" />{{ tBy({ en: 'Online', km: 'អនឡាញ' }) }}</p>
              </div>
            </div>
            <div class="am-messages">
              <div class="am-msg bot">{{ tBy({ en: '✨ Caption generated: "Apsara dancer rendered in 24k gold leaf — a bridge between Angkor\'s sacred tradition and contemporary luminance."', km: '✨ ចំណងជើងបង្កើត: "អប្សរក្នុងមាស — ស្ពានរវាងអង្គរ"' }) }}</div>
              <div class="am-msg bot">{{ tBy({ en: '🏷️ Suggested tags: apsara, gold-leaf, cambodia, contemporary, sacred', km: '🏷️ ស្លាកស្នើ: អប្សរ, មាស, ខ្មែរ, សម័យទំនើប' }) }}</div>
              <div class="am-typing">
                <span /><span /><span />
              </div>
            </div>
            <div class="am-input-row">
              <input class="am-input" :placeholder="tBy({ en: 'Ask RamaAI…', km: 'សួរ RamaAI…' })" readonly />
              <button class="am-send">→</button>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ── Pricing ─────────────────────── -->
    <section id="pricing" class="section pricing-section">
      <div class="container">
        <div class="section-head animate-on-scroll" style="text-align:center">
          <p class="section-label">{{ tBy({ en: 'Plans', km: 'គំរោង' }) }}</p>
          <h2 class="section-title animate-on-scroll delay-1">{{ tBy({ en: 'Simple, Transparent Pricing', km: 'តម្លៃ​សាមញ្ញ' }) }}</h2>
          <p class="pricing-sub animate-on-scroll delay-2">{{ tBy({ en: 'Start free, grow at your own pace', km: 'ចាប់ផ្តើមដោយឥតគិតថ្លៃ' }) }}</p>
        </div>
        <div class="plans-grid">
          <div v-for="(plan, i) in plans" :key="plan.name" class="plan-card card animate-on-scroll" :class="[`delay-${i+1}`, { popular: plan.popular }]">
            <div v-if="plan.popular" class="popular-tag">{{ tBy({ en: 'Most Popular', km: 'ពេញនិយម' }) }}</div>
            <div class="plan-top">
              <h3 class="plan-name">{{ plan.name }}</h3>
              <div class="plan-price">
                <span class="price-val">{{ plan.price }}</span>
                <span class="price-per">/ {{ tBy(plan.period) }}</span>
              </div>
              <p class="plan-tagline">{{ tBy(plan.tagline) }}</p>
            </div>
            <ul class="plan-feats">
              <li v-for="f in plan.features" :key="f.en">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--color-gold)" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
                {{ tBy(f) }}
              </li>
            </ul>
            <NuxtLink to="/register" class="btn plan-btn" :class="plan.popular ? 'btn-primary' : 'btn-outline'">
              {{ tBy({ en: 'Get Started', km: 'ចាប់ផ្តើម' }) }}
            </NuxtLink>
          </div>
        </div>
      </div>
    </section>

    <!-- ── FAQ ───────────────────────────── -->
    <section id="faq" class="section faq-section">
      <div class="container faq-grid">
        <div class="faq-left animate-on-scroll slide-right">
          <p class="section-label">{{ tBy({ en: 'Questions', km: 'សំណួរ' }) }}</p>
          <h2 class="faq-title">{{ tBy({ en: 'Frequently Asked', km: 'ច្រើនសួរ' }) }}</h2>
          <NuxtLink to="/contact" class="btn btn-outline mt-sm">{{ tBy({ en: 'Ask a question', km: 'ផ្ញើសំណួរ' }) }}</NuxtLink>
        </div>
        <div class="faq-right">
          <div v-for="(faq, i) in faqs" :key="faq.q.en" class="faq-item animate-on-scroll" :class="`delay-${i+1}`" @click="openFaq = openFaq === i ? -1 : i">
            <div class="faq-q">
              <span>{{ tBy(faq.q) }}</span>
              <svg class="faq-chevron" :class="{ open: openFaq === i }" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg>
            </div>
            <Transition name="faq">
              <p v-if="openFaq === i" class="faq-a">{{ tBy(faq.a) }}</p>
            </Transition>
          </div>
        </div>
      </div>
    </section>

  </div>
</template>

<script setup lang="ts">
import pagesData from '~/assets/json/pages.json'
import { useTBy } from '~/composables/useTBy'

const { tBy } = useTBy()
useScrollAnimation()

const openFaq = ref(-1)
const services = pagesData.services

const aiFeatures = [
  { icon: '✍️', label: { en: 'Caption Generator', km: 'បង្កើតចំណងជើង' }, desc: { en: 'Describe your artwork in seconds.', km: 'ពិពណ៌នាស្នាដៃក្នុងពេលប៉ុន្មានវិនាទី' } },
  { icon: '🏷️', label: { en: 'Smart Tagging', km: 'ស្លាកឆ្លាត' }, desc: { en: 'Auto-suggest SEO-optimised tags.', km: 'ស្នើស្លាក SEO ដោយស្វ័យ​ប្រវត្តិ' } },
  { icon: '🔍', label: { en: 'Style Analysis', km: 'វិភាគស្ទីល' }, desc: { en: 'Identify your artistic influences.', km: 'កំណត់អត្តសញ្ញាណឥទ្ធិពលសិល្បៈ' } },
  { icon: '⬆️', label: { en: 'Image Upscale', km: 'ដំឡើងរូបភាព' }, desc: { en: 'Enhance resolution without quality loss.', km: 'ប្រសើរ Resolution ដោយគ្មានការបាត់បង់' } },
]

const plans = [
  { name: 'Free', price: '$0', period: { en: 'forever', km: 'ជានិច្ច' }, tagline: { en: 'Perfect to get started', km: 'ល្អឥតខ្ចោះដើម្បីចាប់ផ្តើម' }, popular: false, features: [{ en: '5 artwork uploads', km: 'ស្នាដៃ 5' }, { en: 'Basic portfolio', km: 'ផតហ្វូលីយ៉ូ​មូលដ្ឋាន' }, { en: 'Gallery listing', km: 'ការដាក់បញ្ជី' }, { en: 'Community access', km: 'ការចូលប្រើសហគមន៍' }] },
  { name: 'Artist', price: '$12', period: { en: 'month', km: 'ខែ' }, tagline: { en: 'For active creators', km: 'សម្រាប់អ្នកបង្កើតសកម្ម' }, popular: true, features: [{ en: 'Unlimited artworks', km: 'ស្នាដៃគ្មានដែន' }, { en: 'Custom domain', km: 'ដែននាមផ្ទាល់ខ្លួន' }, { en: 'AI Studio (50 credits)', km: 'AI Studio (50 ស្លាក)' }, { en: 'Advanced analytics', km: 'ការវិភាគ​ជឿនលឿន' }, { en: 'Image protection', km: 'ការការពាររូបភាព' }, { en: 'Priority support', km: 'ជំនួយ​អាទិភាព' }] },
  { name: 'Studio', price: '$39', period: { en: 'month', km: 'ខែ' }, tagline: { en: 'For studios & galleries', km: 'សម្រាប់ Studio' }, popular: false, features: [{ en: 'Everything in Artist', km: 'គ្រប់យ៉ាងក្នុង Artist' }, { en: 'Unlimited AI credits', km: 'AI Credits គ្មានដែន' }, { en: 'Team members (3)', km: 'សមាជិកក្រុម (3)' }, { en: 'Exhibition features', km: 'មុខងារការតាំងបង្ហាញ' }, { en: 'Dedicated curator', km: 'Curator ផ្ទាល់ខ្លួន' }] },
]

const faqs = [
  { q: { en: 'Is my artwork safe on RamaGallery?', km: 'តើស្នាដៃរបស់ខ្ញុំមានសុវត្ថិភាពនៅ RamaGallery?' }, a: { en: 'Yes. We use signed URLs, watermarking, and anti-scraping technology. Your artwork is never indexed by search engines without your permission.', km: 'បាទ/ចាស។ យើងប្រើ signed URL ស្លាកទឹក និងបច្ចេកវិទ្យាប្រឆាំង scraping' } },
  { q: { en: 'Can I sell my art directly through the platform?', km: 'តើខ្ញុំអាចលក់ស្នាដៃដោយផ្ទាល់?' }, a: { en: 'Yes. Artwork Sales is available on Artist and Studio plans with secure payment processing and international shipping support.', km: 'បាទ/ចាស។ ការលក់ស្នាដៃអាចប្រើបានក្នុងគំរោង Artist និង Studio' } },
  { q: { en: 'Does RamaGallery support Khmer language?', km: 'តើ RamaGallery គាំទ្រភាសាខ្មែរ?' }, a: { en: 'Fully. The entire platform — UI, AI captions, tags, and SEO descriptions — operates in both Khmer and English.', km: 'ពេញ។ វេទិកាទាំងមូល ​AI ចំណងជើង ស្លាក និង SEO ដំណើរការជាភាសាខ្មែរ និងអង់គ្លេស' } },
  { q: { en: 'How do I start?', km: 'ខ្ញុំត្រូវចាប់ផ្តើមដូចម្តេច?' }, a: { en: 'Register for free, complete your profile, upload your first artwork, and you\'re live — no credit card required.', km: 'ចុះឈ្មោះដោយឥតគិតថ្លៃ បំពេញប្រវត្តិរូប ហើយបញ្ចូលស្នាដៃដំបូង' } },
]

useSeoMeta({ title: 'Services — RamaGallery', description: 'Tools and services for Cambodian artists.' })
</script>

<style scoped lang="scss">
.services-hero { padding: 6rem 0 4rem; text-align: center; background: linear-gradient(135deg, var(--color-bg-secondary) 0%, var(--color-bg) 60%); border-bottom: 1px solid var(--color-border); position: relative; overflow: hidden; &::before { content: ''; position: absolute; top: -40%; right: -10%; width: 600px; height: 600px; background: radial-gradient(circle, rgba(200,149,28,0.07) 0%, transparent 70%); pointer-events: none; } }
.services-title { font-size: clamp(2.5rem, 7vw, 5rem); margin: 0.5rem 0; }
.services-sub { color: var(--color-text-secondary); max-width: 520px; margin: 0 auto 2rem; }
.hero-ctas { display: flex; justify-content: center; gap: 1rem; flex-wrap: wrap; }

.features-section { }
.section-head { margin-bottom: 3rem; }
.section-title { font-size: clamp(2rem, 4vw, 3rem); margin-top: 0.5rem; }

.services-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1.25rem; }
.svc-card { padding: 2rem; position: relative; overflow: hidden; transition: all var(--transition); &:hover { transform: translateY(-4px); border-color: var(--color-gold); box-shadow: var(--shadow-gold); } &:hover .svc-arrow { opacity: 1; transform: translate(0,0); } }
.svc-icon-wrap { width: 52px; height: 52px; background: var(--color-bg-secondary); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; margin-bottom: 1.25rem; }
.svc-icon { font-size: 1.5rem; }
.svc-title { font-family: var(--font-display); font-size: 1.2rem; margin-bottom: 0.75rem; }
.svc-desc { font-size: 0.875rem; color: var(--color-text-secondary); line-height: 1.7; }
.svc-arrow { position: absolute; bottom: 1.25rem; right: 1.25rem; color: var(--color-gold); opacity: 0; transform: translate(-4px, 4px); transition: all var(--transition); }

// AI section
.ai-section { background: var(--color-bg-secondary); }
.ai-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: center; @media (max-width: 900px) { grid-template-columns: 1fr; } }
.ai-title { font-size: clamp(2rem, 4vw, 3rem); margin: 0.5rem 0 1.25rem; }
.ai-desc { font-size: 0.95rem; color: var(--color-text-secondary); line-height: 1.8; margin-bottom: 1.75rem; }
.ai-features { display: flex; flex-direction: column; gap: 1.25rem; margin-bottom: 2rem; }
.ai-feat { display: flex; align-items: flex-start; gap: 0.875rem; }
.af-icon { font-size: 1.25rem; flex-shrink: 0; }
.af-label { font-size: 0.9rem; font-weight: 600; display: block; color: var(--color-text-primary); margin-bottom: 0.15rem; }
.af-desc { font-size: 0.82rem; color: var(--color-text-secondary); }
.mt-cta { margin-top: 0.5rem; }

.ai-mockup { border-radius: var(--radius-lg); padding: 1.5rem; display: flex; flex-direction: column; gap: 1rem; }
.am-header { display: flex; align-items: center; gap: 0.875rem; padding-bottom: 1rem; border-bottom: 1px solid var(--color-border); }
.am-avatar { width: 40px; height: 40px; background: var(--color-gold); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; font-family: var(--font-display); font-size: 1.25rem; flex-shrink: 0; }
.am-name { font-weight: 600; font-size: 0.9rem; color: var(--color-text-primary); }
.am-status { display: flex; align-items: center; gap: 0.375rem; font-size: 0.75rem; color: var(--color-text-muted); }
.status-dot { width: 6px; height: 6px; background: #10b981; border-radius: 50%; }
.am-messages { display: flex; flex-direction: column; gap: 0.75rem; min-height: 120px; }
.am-msg { font-size: 0.82rem; line-height: 1.6; padding: 0.75rem 1rem; border-radius: var(--radius-md); &.bot { background: var(--color-bg-secondary); color: var(--color-text-primary); } }
.am-typing { display: flex; align-items: center; gap: 4px; padding: 0.5rem 0.75rem; span { width: 6px; height: 6px; background: var(--color-text-muted); border-radius: 50%; animation: pulse 1.2s ease-in-out infinite; &:nth-child(2) { animation-delay: 0.2s; } &:nth-child(3) { animation-delay: 0.4s; } } }
.am-input-row { display: flex; gap: 0.5rem; }
.am-input { flex: 1; background: var(--color-bg-secondary); border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: 0.6rem 0.875rem; font-size: 0.83rem; color: var(--color-text-muted); cursor: default; }
.am-send { width: 36px; height: 36px; background: var(--color-gold); border: none; border-radius: var(--radius-sm); color: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 1rem; }

// Pricing
.pricing-section { }
.pricing-sub { color: var(--color-text-secondary); margin-top: 0.5rem; }
.plans-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.25rem; margin-top: 3rem; @media (max-width: 900px) { grid-template-columns: 1fr; } }
.plan-card { padding: 2rem; position: relative; transition: all var(--transition); &.popular { border-color: var(--color-gold); box-shadow: var(--shadow-gold); transform: scale(1.03); @media (max-width: 900px) { transform: none; } } &:hover:not(.popular) { transform: translateY(-3px); } }
.popular-tag { position: absolute; top: -12px; left: 50%; transform: translateX(-50%); background: var(--color-gold); color: #fff; font-size: 0.65rem; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; padding: 0.3rem 1rem; border-radius: var(--radius-full); white-space: nowrap; }
.plan-top { margin-bottom: 1.5rem; }
.plan-name { font-family: var(--font-display); font-size: 1.3rem; margin-bottom: 0.75rem; }
.plan-price { display: flex; align-items: baseline; gap: 0.25rem; margin-bottom: 0.5rem; }
.price-val { font-family: var(--font-display); font-size: 2.75rem; color: var(--color-text-primary); }
.price-per { font-size: 0.85rem; color: var(--color-text-muted); }
.plan-tagline { font-size: 0.83rem; color: var(--color-text-secondary); }
.plan-feats { list-style: none; display: flex; flex-direction: column; gap: 0.75rem; margin-bottom: 2rem; li { display: flex; align-items: center; gap: 0.625rem; font-size: 0.875rem; color: var(--color-text-secondary); } }
.plan-btn { width: 100%; }

// FAQ
.faq-section { background: var(--color-bg-secondary); }
.faq-grid { display: grid; grid-template-columns: 300px 1fr; gap: 5rem; @media (max-width: 768px) { grid-template-columns: 1fr; gap: 2rem; } }
.faq-title { font-family: var(--font-display); font-size: clamp(2rem, 4vw, 2.75rem); margin-top: 0.5rem; }
.mt-sm { margin-top: 1.5rem; }
.faq-item { border-bottom: 1px solid var(--color-border); cursor: pointer; &:first-child { border-top: 1px solid var(--color-border); } }
.faq-q { display: flex; align-items: center; justify-content: space-between; gap: 1rem; padding: 1.25rem 0; font-size: 0.95rem; font-weight: 500; color: var(--color-text-primary); }
.faq-chevron { color: var(--color-text-muted); transition: transform var(--transition); flex-shrink: 0; &.open { transform: rotate(180deg); color: var(--color-gold); } }
.faq-a { padding: 0 0 1.25rem; font-size: 0.875rem; color: var(--color-text-secondary); line-height: 1.75; }
.faq-enter-active, .faq-leave-active { transition: opacity 0.2s ease, max-height 0.3s ease; overflow: hidden; max-height: 200px; }
.faq-enter-from, .faq-leave-to { opacity: 0; max-height: 0; }
</style>
