<template>
  <div>
    <HeroSection />
    <FeaturedArtworks />
    <TrendingArtists />

    <!-- Events teaser -->
    <section class="section events-teaser">
      <div class="container">
        <div class="events-head animate-on-scroll">
          <div>
            <p class="section-label">{{ tBy({ en: 'Upcoming', km: 'ព្រឹត្តិការណ៍ខាងមុខ' }) }}</p>
            <h2 class="section-title">{{ tBy({ en: 'Art Events', km: 'ព្រឹត្តិការណ៍សិល្បៈ' }) }}</h2>
          </div>
          <NuxtLink to="/events" class="btn btn-outline">{{ t('common.view_all') }}</NuxtLink>
        </div>

        <div class="events-list">
          <div
            v-for="(ev, i) in events"
            :key="ev.id"
            class="event-row animate-on-scroll"
            :style="{ animationDelay: `${i * 0.1}s` }"
          >
            <NuxtLink :to="`/events/${ev.slug}`" class="event-link">
              <div class="event-date">
                <span class="date-day">{{ new Date(ev.date).getDate() }}</span>
                <span class="date-month">{{ new Date(ev.date).toLocaleString('en', { month: 'short' }) }}</span>
              </div>
              <div class="event-img">
                <img :src="ev.image" :alt="ev.title" />
              </div>
              <div class="event-info">
                <span class="tag tag-gold">{{ ev.category }}</span>
                <h3 class="event-title">{{ tBy({ en: ev.title, km: ev.title_km }) }}</h3>
                <p class="event-location">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>
                  </svg>
                  {{ ev.location }}
                </p>
              </div>
              <div class="event-arrow">→</div>
            </NuxtLink>
          </div>
        </div>
      </div>
    </section>

    <!-- Services snippet -->
    <section class="section services-snippet">
      <div class="container">
        <div class="services-head animate-on-scroll">
          <p class="section-label">{{ tBy({ en: 'What we offer', km: 'អ្វីដែលយើងផ្តល់' }) }}</p>
          <h2 class="section-title">{{ tBy({ en: 'Platform Features', km: 'មុខងារវេទិកា' }) }}</h2>
        </div>
        <div class="services-grid">
          <div
            v-for="(s, i) in services"
            :key="s.id"
            class="service-card animate-on-scroll"
            :style="{ animationDelay: `${i * 0.08}s` }"
          >
            <span class="service-icon">{{ s.icon }}</span>
            <h4 class="service-title">{{ tBy(s.title) }}</h4>
            <p class="service-desc">{{ tBy(s.description) }}</p>
          </div>
        </div>
        <div class="services-cta animate-on-scroll">
          <NuxtLink to="/services" class="btn btn-outline">{{ tBy({ en: 'All Services', km: 'សេវាកម្មទាំងអស់' }) }}</NuxtLink>
          <NuxtLink to="/register" class="btn btn-primary">{{ t('nav.register') }}</NuxtLink>
        </div>
      </div>
    </section>

    <TestimonialsSection />

    <!-- Final CTA band -->
    <section class="cta-band">
      <div class="cta-band-inner animate-on-scroll">
        <p class="section-label">{{ tBy({ en: 'Join the movement', km: 'ចូលរួមការចលនា' }) }}</p>
        <h2 class="cta-band-title">{{ tBy({ en: 'Your art deserves a home.', km: 'សិល្បៈរបស់អ្នកសមនឹងមានទីស្នាក់ការ' }) }}</h2>
        <NuxtLink to="/register" class="btn btn-primary cta-btn">
          {{ tBy({ en: 'Start your portfolio', km: 'ចាប់ផ្តើមផតហ្វូលីយ៉ូ' }) }}
        </NuxtLink>
      </div>
    </section>
  </div>
</template>

<script setup lang="ts">
import pagesData from '~/assets/json/pages.json'
import { useTBy } from '~/composables/useTBy'
import { useScrollAnimation } from '~/composables/useScrollAnimation'

const { t } = useI18n()
const { tBy } = useTBy()
useScrollAnimation()

const events = pagesData.events.slice(0, 3)
const services = pagesData.services

useSeoMeta({
  title: 'RamaGallery — Cambodia\'s Art Platform',
  ogTitle: 'RamaGallery',
  description: 'Discover extraordinary Cambodian art. Browse artworks, follow artists, and connect with a global collector community.',
  ogDescription: 'Discover extraordinary Cambodian art.',
})
</script>

<style scoped lang="scss">
.section { padding: var(--section-gap) 0; }
.container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2rem;
}

// Events teaser
.events-teaser { background: var(--color-bg-secondary); }

.events-head {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  margin-bottom: 2.5rem;
  gap: 1rem;
}

.section-title {
  font-size: clamp(2rem, 4vw, 2.75rem);
  margin: 0.5rem 0 0;
}

.events-list { display: flex; flex-direction: column; gap: 0; }

.event-row {
  border-bottom: 1px solid var(--color-border);

  &:first-child { border-top: 1px solid var(--color-border); }
}

.event-link {
  display: flex;
  align-items: center;
  gap: 1.5rem;
  padding: 1.25rem 0;
  text-decoration: none;
  transition: all var(--transition);

  &:hover .event-title { color: var(--color-gold); }
  &:hover .event-arrow { transform: translateX(4px); color: var(--color-gold); }
}

.event-date {
  display: flex;
  flex-direction: column;
  align-items: center;
  min-width: 44px;
}

.date-day {
  font-family: var(--font-display);
  font-size: 1.75rem;
  font-weight: 500;
  line-height: 1;
  color: var(--color-gold);
}

.date-month {
  font-size: 0.7rem;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  color: var(--color-text-muted);
}

.event-img {
  width: 72px;
  height: 52px;
  border-radius: 4px;
  overflow: hidden;
  flex-shrink: 0;

  img { width: 100%; height: 100%; object-fit: cover; }
}

.event-info { flex: 1; }

.event-title {
  font-family: var(--font-display);
  font-size: 1.1rem;
  font-weight: 400;
  color: var(--color-text-primary);
  margin: 0.25rem 0 0.375rem;
  transition: color var(--transition);
}

.event-location {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  font-size: 0.8rem;
  color: var(--color-text-muted);
}

.event-arrow {
  font-size: 1.2rem;
  color: var(--color-text-muted);
  transition: all var(--transition);
}

// Services
.services-snippet { }

.services-head {
  text-align: center;
  margin-bottom: 3rem;
}

.services-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 1.25rem;
}

.service-card {
  padding: 1.75rem;
  background: var(--color-bg-card);
  border: 1px solid var(--color-border);
  border-radius: 8px;
  transition: all var(--transition);

  &:hover {
    border-color: var(--color-gold);
    transform: translateY(-2px);
  }
}

.service-icon {
  font-size: 1.75rem;
  display: block;
  margin-bottom: 1rem;
}

.service-title {
  font-family: var(--font-display);
  font-size: 1.1rem;
  font-weight: 400;
  color: var(--color-text-primary);
  margin-bottom: 0.625rem;
}

.service-desc {
  font-size: 0.875rem;
  color: var(--color-text-secondary);
  line-height: 1.65;
}

.services-cta {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  margin-top: 3rem;
}

// CTA band
.cta-band {
  background: var(--color-text-primary);
  padding: 6rem 2rem;
}

.cta-band-inner {
  max-width: 700px;
  margin: 0 auto;
  text-align: center;

  .section-label { color: var(--color-gold); }
}

.cta-band-title {
  font-family: var(--font-display);
  font-size: clamp(2.5rem, 5vw, 4rem);
  font-weight: 400;
  color: var(--color-bg);
  margin: 1rem 0 2.5rem;
  line-height: 1.1;
}

.dark .cta-band {
  background: var(--color-bg-secondary);
  .cta-band-title { color: var(--color-text-primary); }
}
</style>
