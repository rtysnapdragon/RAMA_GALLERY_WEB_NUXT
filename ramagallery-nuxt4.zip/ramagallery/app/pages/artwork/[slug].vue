<template>
  <div v-if="artwork" class="artwork-page">
    <!-- Image viewer -->
    <div class="viewer-section">
      <div class="viewer-wrap">
        <RAImage
          :src="artwork.image"
          :alt="artwork.title"
          class="viewer-image"
          :class="{ zoomed }"
          @click="zoomed = !zoomed"
        />
        <button class="zoom-btn" :title="zoomed ? 'Zoom out' : 'Zoom in'" @click="zoomed = !zoomed">
          <svg v-if="!zoomed" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
            <circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/>
          </svg>
          <svg v-else width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
            <circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="8" y1="11" x2="14" y2="11"/>
          </svg>
        </button>
      </div>
    </div>

    <!-- Info panel -->
    <div class="info-section">
      <div class="info-inner">
        <!-- Breadcrumb -->
        <nav class="breadcrumb">
          <NuxtLink to="/gallery">Gallery</NuxtLink>
          <span>/</span>
          <span>{{ artwork.title }}</span>
        </nav>

        <!-- Tags -->
        <div class="tags-row">
          <span v-for="tag in artwork.tags" :key="tag" class="tag">{{ tag }}</span>
        </div>

        <!-- Title -->
        <h1 class="artwork-title">{{ artwork.title }}</h1>

        <!-- Artist -->
        <NuxtLink :to="`/artists/${artwork.artist.slug}`" class="artist-link-row">
          <img :src="artwork.artist.avatar" :alt="artwork.artist.name" class="artist-avatar" />
          <div>
            <p class="artist-link-label">{{ t('artwork.by') }}</p>
            <p class="artist-link-name">{{ artwork.artist.name }}</p>
          </div>
        </NuxtLink>

        <div class="divider-gold" />

        <!-- Description -->
        <p class="artwork-desc">{{ artwork.description }}</p>

        <!-- Meta -->
        <div class="meta-grid">
          <div class="meta-item">
            <span class="meta-label">Category</span>
            <span class="meta-value">{{ artwork.category }}</span>
          </div>
          <div class="meta-item">
            <span class="meta-label">Year</span>
            <span class="meta-value">{{ artwork.year }}</span>
          </div>
          <div class="meta-item">
            <span class="meta-label">Price</span>
            <span class="meta-value gold">${{ artwork.price.toLocaleString() }}</span>
          </div>
        </div>

        <!-- Actions -->
        <div class="action-row">
          <button :class="['btn', 'btn-outline', 'action-btn', { liked: isLiked }]" @click="toggleLike">
            <svg width="16" height="16" viewBox="0 0 24 24" :fill="isLiked ? 'currentColor' : 'none'" stroke="currentColor" stroke-width="2" stroke-linecap="round">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
            </svg>
            {{ artwork.likes + (isLiked ? 1 : 0) }} {{ t('artwork.likes') }}
          </button>

          <button :class="['btn', 'btn-outline', 'action-btn', { saved: isSaved }]" @click="toggleSave">
            <svg width="16" height="16" viewBox="0 0 24 24" :fill="isSaved ? 'currentColor' : 'none'" stroke="currentColor" stroke-width="2" stroke-linecap="round">
              <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
            </svg>
            {{ t('artwork.saves') }}
          </button>

          <button class="btn btn-ghost action-btn" @click="shareArtwork">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
              <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
            </svg>
            {{ t('common.share') }}
          </button>
        </div>

        <button class="btn btn-primary purchase-btn">
          Inquire to Purchase
        </button>

        <!-- Protected note -->
        <p class="protected-note">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
          {{ t('artwork.protected') }}
        </p>

        <!-- Comments -->
        <div class="comments-section">
          <h3 class="comments-title">
            {{ t('artwork.comments') }}
            <span class="comments-count">{{ comments.length }}</span>
          </h3>

          <!-- Add comment -->
          <div v-if="auth.isLoggedIn" class="comment-form">
            <img :src="auth.user?.avatar ?? ''" :alt="auth.displayName" class="comment-avatar" />
            <div class="comment-input-wrap">
              <input
                v-model="newComment"
                class="input comment-input"
                :placeholder="t('artwork.add_comment')"
                @keydown.enter="postComment"
              />
              <button class="comment-send" :disabled="!newComment.trim()" @click="postComment">↗</button>
            </div>
          </div>
          <p v-else class="login-prompt">
            <NuxtLink :to="localePath('/login')">{{ t('artwork.login_to_comment') }}</NuxtLink>
          </p>

          <!-- Comment list -->
          <div class="comment-list">
            <div v-for="c in comments" :key="c.id" class="comment-item">
              <img :src="c.avatar" :alt="c.name" class="comment-avatar" />
              <div class="comment-body">
                <div class="comment-header">
                  <span class="comment-name">{{ c.name }}</span>
                  <span class="comment-time">{{ c.time }}</span>
                </div>
                <p class="comment-text">{{ c.text }}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Related artworks -->
  <section v-if="related.length" class="related-section">
    <div class="container">
      <h2 class="related-title">{{ t('artwork.related') }}</h2>
      <div class="related-grid">
        <NuxtLink
          v-for="a in related"
          :key="a.id"
          :to="`/artwork/${a.slug}`"
          class="related-card"
        >
          <RAImage :src="a.image" :alt="a.title" ratio="4/3" cover />
          <p class="related-card-title">{{ a.title }}</p>
        </NuxtLink>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import pagesData from '~/assets/json/pages.json'

const route = useRoute()
const { t } = useI18n()
const auth = useAuthStore()
const router = useRouter()
const localePath = useLocalePath()

const artwork = computed(() => pagesData.artworks.find(a => a.slug === route.params.slug))

const related = computed(() =>
  pagesData.artworks
    .filter(a => a.id !== artwork.value?.id && a.category === artwork.value?.category)
    .slice(0, 4)
)

const zoomed = ref(false)
const isLiked = ref(false)
const isSaved = ref(false)
const newComment = ref('')

const comments = ref([
  { id: 1, name: 'Bopha Nhem', avatar: 'https://api.dicebear.com/7.x/personas/svg?seed=bopha', text: 'Absolutely breathtaking — the gold leaf technique is masterful!', time: '2h ago' },
  { id: 2, name: 'Vireak Chhem', avatar: 'https://api.dicebear.com/7.x/personas/svg?seed=vireak', text: 'The way you\'ve merged classical iconography with contemporary form is truly inspiring.', time: '5h ago' },
])

const toggleLike = () => {
  if (!auth.isLoggedIn) return router.push(localePath('/login'))
  isLiked.value = !isLiked.value
}

const toggleSave = () => {
  if (!auth.isLoggedIn) return router.push(localePath('/login'))
  isSaved.value = !isSaved.value
}

const shareArtwork = () => {
  if (navigator.share) {
    navigator.share({ title: artwork.value?.title, url: window.location.href })
  } else {
    navigator.clipboard.writeText(window.location.href)
  }
}

const postComment = () => {
  if (!newComment.value.trim()) return
  comments.value.unshift({
    id: Date.now(),
    name: auth.displayName,
    avatar: auth.user?.avatar ?? '',
    text: newComment.value,
    time: 'Just now',
  })
  newComment.value = ''
}

if (!artwork.value) throw createError({ statusCode: 404, statusMessage: 'Artwork not found' })

useSeoMeta({
  title: `${artwork.value?.title} — RamaGallery`,
  description: artwork.value?.description,
})
</script>

<style scoped lang="scss">
.artwork-page {
  display: grid;
  grid-template-columns: 1fr 420px;
  min-height: calc(100vh - var(--header-height));

  @media (max-width: 900px) {
    grid-template-columns: 1fr;
  }
}

.viewer-section {
  position: sticky;
  top: var(--header-height);
  height: calc(100vh - var(--header-height));
  overflow: hidden;
  background: var(--color-bg-secondary);
  display: flex;
  align-items: center;
  justify-content: center;

  @media (max-width: 900px) {
    position: relative;
    height: 55vw;
    min-height: 260px;
  }
}

.viewer-wrap {
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.viewer-image {
  max-width: 100%;
  max-height: 100%;
  transition: transform 0.4s ease;
  cursor: zoom-in;

  &.zoomed {
    transform: scale(1.4);
    cursor: zoom-out;
  }
}

.zoom-btn {
  position: absolute;
  bottom: 1.25rem;
  right: 1.25rem;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: var(--glass-bg);
  backdrop-filter: blur(8px);
  border: 1px solid var(--glass-border);
  color: var(--color-text-primary);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all var(--transition);

  &:hover { border-color: var(--color-gold); color: var(--color-gold); }
}

.info-section {
  border-left: 1px solid var(--color-border);
  overflow-y: auto;
  @media (max-width: 900px) { border-left: none; border-top: 1px solid var(--color-border); }
}

.info-inner {
  padding: 2rem 1.75rem 3rem;
  max-width: 100%;
}

.breadcrumb {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.8rem;
  color: var(--color-text-muted);
  margin-bottom: 1.25rem;

  a { color: var(--color-text-muted); text-decoration: none; &:hover { color: var(--color-gold); } }
}

.tags-row {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.artwork-title {
  font-family: var(--font-display);
  font-size: 2rem;
  font-weight: 400;
  color: var(--color-text-primary);
  margin-bottom: 1.25rem;
  line-height: 1.15;
}

.artist-link-row {
  display: flex;
  align-items: center;
  gap: 0.875rem;
  text-decoration: none;
  padding: 0.875rem;
  border-radius: 8px;
  border: 1px solid var(--color-border);
  margin-bottom: 1.5rem;
  transition: all var(--transition);

  &:hover { border-color: var(--color-gold); }
}

.artist-avatar { width: 44px; height: 44px; border-radius: 50%; object-fit: cover; }
.artist-link-label { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-text-muted); }
.artist-link-name { font-weight: 500; color: var(--color-text-primary); margin-top: 0.125rem; }

.divider-gold { max-width: 100%; margin: 1.5rem 0; }

.artwork-desc { font-size: 0.9375rem; color: var(--color-text-secondary); line-height: 1.75; margin-bottom: 1.5rem; }

.meta-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1rem;
  margin-bottom: 1.75rem;
}

.meta-item {
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}

.meta-label { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--color-text-muted); }
.meta-value { font-size: 0.9375rem; font-weight: 500; color: var(--color-text-primary); &.gold { color: var(--color-gold); } }

.action-row {
  display: flex;
  gap: 0.625rem;
  margin-bottom: 1rem;
  flex-wrap: wrap;
}

.action-btn {
  padding: 0.6rem 1rem;
  font-size: 0.8125rem;

  &.liked { color: #e53e3e; border-color: #e53e3e; }
  &.saved { color: var(--color-gold); border-color: var(--color-gold); }
}

.purchase-btn {
  width: 100%;
  padding: 0.875rem;
  font-size: 0.9rem;
  letter-spacing: 0.06em;
  margin-bottom: 0.875rem;
}

.protected-note {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  font-size: 0.75rem;
  color: var(--color-text-muted);
  margin-bottom: 2rem;
}

.comments-section { border-top: 1px solid var(--color-border); padding-top: 1.5rem; }

.comments-title {
  font-family: var(--font-display);
  font-size: 1.25rem;
  font-weight: 400;
  color: var(--color-text-primary);
  margin-bottom: 1.25rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.comments-count {
  font-family: var(--font-sans);
  font-size: 0.8125rem;
  color: var(--color-text-muted);
  font-weight: 400;
}

.comment-form {
  display: flex;
  gap: 0.75rem;
  margin-bottom: 1.5rem;
}

.comment-input-wrap {
  flex: 1;
  position: relative;
  display: flex;
}

.comment-input { padding-right: 2.5rem; border-radius: 20px; }

.comment-send {
  position: absolute;
  right: 0.625rem;
  top: 50%;
  transform: translateY(-50%);
  background: var(--color-gold);
  border: none;
  color: #fff;
  width: 28px;
  height: 28px;
  border-radius: 50%;
  cursor: pointer;
  font-size: 0.875rem;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all var(--transition);

  &:disabled { opacity: 0.4; cursor: not-allowed; }
  &:not(:disabled):hover { background: var(--color-gold-dark); }
}

.login-prompt {
  font-size: 0.875rem;
  color: var(--color-text-muted);
  margin-bottom: 1.5rem;
  a { color: var(--color-gold); text-decoration: none; }
}

.comment-avatar { width: 32px; height: 32px; border-radius: 50%; object-fit: cover; flex-shrink: 0; }

.comment-list { display: flex; flex-direction: column; gap: 1rem; }

.comment-item { display: flex; gap: 0.75rem; }

.comment-body { flex: 1; }

.comment-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.25rem; }

.comment-name { font-size: 0.875rem; font-weight: 500; color: var(--color-text-primary); }
.comment-time { font-size: 0.75rem; color: var(--color-text-muted); }
.comment-text { font-size: 0.875rem; color: var(--color-text-secondary); line-height: 1.6; }

// Related
.related-section { padding: 4rem 0; background: var(--color-bg-secondary); border-top: 1px solid var(--color-border); }
.container { max-width: 1400px; margin: 0 auto; padding: 0 2rem; }
.related-title { font-family: var(--font-display); font-size: 1.75rem; font-weight: 400; margin-bottom: 2rem; }
.related-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem; }
.related-card { display: block; text-decoration: none; border-radius: 4px; overflow: hidden; border: 1px solid var(--color-border); transition: all var(--transition); &:hover { border-color: var(--color-gold); transform: translateY(-2px); } }
.related-card-title { font-size: 0.875rem; color: var(--color-text-primary); padding: 0.625rem 0.75rem; }
</style>
