/**
 * useScrollAnimation — IntersectionObserver for animate-on-scroll
 * Adds .in-view when element crosses viewport threshold
 */
export function useScrollAnimation() {
  const observe = () => {
    if (!import.meta.client) return
    const els = document.querySelectorAll('.animate-on-scroll')
    const io = new IntersectionObserver(
      (entries) => entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in-view'); io.unobserve(e.target) } }),
      { threshold: 0.1, rootMargin: '0px 0px -48px 0px' }
    )
    els.forEach(el => io.observe(el))
    return () => io.disconnect()
  }
  onMounted(() => { const cleanup = observe(); onUnmounted(() => cleanup?.()) })
}
