/**
 * tBy — Inline bilingual string helper
 * Usage: tBy({ en: 'Hello', km: 'សួស្តី' })
 */

import { useI18n } from 'vue-i18n'

export function useTBy() {
  const { locale } = useI18n()

  function tBy(obj: { en: string; km: string }): string {
    return locale.value === 'km' ? obj.km : obj.en
  }

  return { tBy }
}
