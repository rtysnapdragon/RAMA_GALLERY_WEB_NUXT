// middleware/auth.ts — Redirect to login if not authenticated
export default defineNuxtRouteMiddleware((to) => {
  const auth = useAuthStore()
  // Re-hydrate from localStorage on each navigation
  if (import.meta.client && !auth.isLoggedIn) {
    auth.initFromStorage()
  }
  if (!auth.isLoggedIn) {
    return navigateTo(`/login?redirect=${encodeURIComponent(to.fullPath)}`)
  }
})
