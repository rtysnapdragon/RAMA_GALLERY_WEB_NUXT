// middleware/guest.ts — Redirect authenticated users away from auth pages
export default defineNuxtRouteMiddleware(() => {
  const auth = useAuthStore()
  if (import.meta.client && !auth.isLoggedIn) {
    auth.initFromStorage()
  }
  if (auth.isLoggedIn) {
    return navigateTo('/dashboard')
  }
})
