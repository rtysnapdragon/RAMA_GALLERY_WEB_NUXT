<template>
  <Teleport to="body">
    <Transition name="scroll-btn">
      <button
        v-if="show"
        class="scroll-top-btn"
        @click="scrollTop"
        :data-tooltip="tBy({ en: 'Back to top', km: 'ត្រឡប់ទៅលើ' })"
        aria-label="Scroll to top"
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 19V5"/><path d="m5 12 7-7 7 7"/></svg>
      </button>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
import { useTBy } from '~/composables/useTBy'
const { tBy } = useTBy()
const show = ref(false)
const scrollTop = () => window.scrollTo({ top: 0, behavior: 'smooth' })
onMounted(() => {
  const handler = () => { show.value = window.scrollY > 400 }
  window.addEventListener('scroll', handler, { passive: true })
  onUnmounted(() => window.removeEventListener('scroll', handler))
})
</script>

<style scoped lang="scss">
.scroll-top-btn {
  position: fixed;
  bottom: 7rem;
  right: 1.5rem;
  width: 44px;
  height: 44px;
  border-radius: 50%;
  background: var(--color-gold);
  border: none;
  color: #fff;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 90;
  box-shadow: 0 4px 16px rgba(200,149,28,0.4);
  transition: all var(--transition);
  &:hover { transform: translateY(-3px); background: var(--color-gold-dark); }
}
.scroll-btn-enter-active, .scroll-btn-leave-active { transition: opacity 0.3s ease, transform 0.3s ease; }
.scroll-btn-enter-from, .scroll-btn-leave-to { opacity: 0; transform: translateY(12px) scale(0.85); }
</style>
