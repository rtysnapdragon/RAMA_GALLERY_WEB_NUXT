<template>
  <div
    class="ra-image-wrapper"
    :class="[aspectClass, { 'ra-blur': isBlurred }]"
    @contextmenu.prevent
    @dragstart.prevent
    ref="wrapperRef"
  >
    <div v-if="isLoading" class="ra-placeholder skeleton" />
    <img
      v-show="!isLoading"
      :src="resolvedSrc"
      :alt="alt"
      loading="lazy"
      draggable="false"
      @load="onLoad"
      @error="onError"
      class="ra-img"
    />
    <div class="protect-overlay" />
    <div v-if="watermark" class="ra-watermark">ར RamaGallery</div>
    <div v-if="hasError" class="ra-error">
      <span>Protected image</span>
    </div>
  </div>
</template>

<script setup lang="ts">
interface Props {
  src: string
  alt?: string
  aspect?: 'square' | 'portrait' | 'landscape' | 'wide' | 'auto'
  watermark?: boolean
  blur?: boolean
}
const props = withDefaults(defineProps<Props>(), {
  alt: 'Artwork',
  aspect: 'auto',
  watermark: true,
  blur: false,
})
const isLoading = ref(true)
const hasError = ref(false)
const isBlurred = ref(props.blur)
const wrapperRef = ref<HTMLElement>()
const resolvedSrc = computed(() => props.src)
const aspectClass = computed(() => ({ square: 'aspect-square', portrait: 'aspect-portrait', landscape: 'aspect-landscape', wide: 'aspect-wide', auto: '' }[props.aspect] ?? ''))
const onLoad = () => { isLoading.value = false }
const onError = () => { isLoading.value = false; hasError.value = true }
onMounted(() => {
  const el = wrapperRef.value
  if (!el) return
  el.addEventListener('contextmenu', (e) => e.preventDefault())
})
</script>

<style scoped lang="scss">
.ra-image-wrapper { position: relative; overflow: hidden; background: var(--color-bg-secondary); border-radius: inherit; }
.aspect-square { aspect-ratio: 1 / 1; }
.aspect-portrait { aspect-ratio: 3 / 4; }
.aspect-landscape { aspect-ratio: 4 / 3; }
.aspect-wide { aspect-ratio: 16 / 9; }
.ra-placeholder { position: absolute; inset: 0; width: 100%; height: 100%; }
.ra-img { display: block; width: 100%; height: 100%; object-fit: cover; user-select: none; -webkit-user-drag: none; pointer-events: none; transition: transform 0.6s ease; }
.ra-image-wrapper:hover .ra-img { transform: scale(1.04); }
.protect-overlay { position: absolute; inset: 0; z-index: 3; pointer-events: none; }
.ra-watermark { position: absolute; bottom: 10px; right: 12px; font-size: 0.6rem; font-weight: 600; letter-spacing: 0.18em; text-transform: uppercase; color: rgba(255,255,255,0.35); z-index: 4; pointer-events: none; text-shadow: 0 1px 3px rgba(0,0,0,0.6); }
.ra-error { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; color: var(--color-text-muted); font-size: 0.8rem; background: var(--color-bg-secondary); }
.ra-blur .ra-img { filter: blur(12px); transform: scale(1.05); }
</style>
