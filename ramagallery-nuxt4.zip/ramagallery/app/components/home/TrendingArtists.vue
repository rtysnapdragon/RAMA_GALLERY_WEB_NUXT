<template>
  <section class="section artists-section">
    <div class="container">
      <div class="artists-head animate-on-scroll">
        <div>
          <p class="section-label">{{ t('home.trending_title') }}</p>
          <h2 class="section-title">{{ tBy({ en: 'Meet the Creators', km: 'ស្គាល់វិចិត្រករ' }) }}</h2>
        </div>
        <NuxtLink to="/artists" class="btn btn-outline">{{ t('common.view_all') }}</NuxtLink>
      </div>

      <div class="artists-grid">
        <div
          v-for="(artist, i) in artists"
          :key="artist.id"
          class="artist-card animate-on-scroll"
          :style="{ animationDelay: `${i * 0.1}s` }"
        >
          <NuxtLink :to="`/artists/${artist.slug}`" class="artist-link">
            <div class="artist-cover">
              <img :src="artist.cover" :alt="artist.name" class="cover-img" />
              <div class="cover-gradient" />
              <div v-if="artist.verified" class="verified-badge">✓</div>
            </div>
            <div class="artist-info">
              <img :src="artist.avatar" :alt="artist.name" class="artist-avatar" />
              <h3 class="artist-name">{{ artist.name }}</h3>
              <p class="artist-specialty">{{ artist.specialty }}</p>
              <div class="artist-stats">
                <span>{{ artist.artworks_count }} {{ tBy({ en: 'works', km: 'ស្នាដៃ' }) }}</span>
                <span class="divider-dot">·</span>
                <span>{{ formatNum(artist.followers) }} {{ tBy({ en: 'followers', km: 'អ្នកតាមដាន' }) }}</span>
              </div>
              <button class="btn btn-outline follow-btn" @click.prevent="handleFollow(artist.id)">
                {{ followedIds.has(artist.id) ? t('artist.following') : t('artist.follow') }}
              </button>
            </div>
          </NuxtLink>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import pagesData from '~/assets/json/pages.json'
import { useTBy } from '~/composables/useTBy'

const { t } = useI18n()
const { tBy } = useTBy()
const auth = useAuthStore()
const router = useRouter()
const localePath = useLocalePath()

const artists = pagesData.artists.filter(a => a.featured)
const followedIds = ref<Set<number>>(new Set())

const formatNum = (n: number) => n >= 1000 ? `${(n / 1000).toFixed(1)}K` : String(n)

const handleFollow = (id: number) => {
  if (!auth.isLoggedIn) return router.push(localePath('/login'))
  followedIds.value.has(id) ? followedIds.value.delete(id) : followedIds.value.add(id)
}
</script>

<style scoped lang="scss">
.artists-section {
  padding: var(--section-gap) 0;
  background: var(--color-bg-secondary);
}

.container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2rem;
}

.artists-head {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  margin-bottom: 3rem;
  gap: 1rem;

  @media (max-width: 580px) { flex-direction: column; align-items: flex-start; }
}

.section-title {
  font-size: clamp(2rem, 4vw, 2.75rem);
  margin: 0.5rem 0 0;
}

.artists-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 1.5rem;
}

.artist-card {
  border-radius: 8px;
  overflow: hidden;
  background: var(--color-bg-card);
  border: 1px solid var(--color-border);
  transition: all var(--transition);

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 20px 48px rgba(26,22,18,0.1);
    border-color: var(--color-gold);
  }
}

.dark .artist-card:hover {
  box-shadow: 0 20px 48px rgba(0,0,0,0.3);
}

.artist-link { display: block; text-decoration: none; }

.artist-cover {
  position: relative;
  height: 140px;
  overflow: hidden;
}

.cover-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.5s ease;
  pointer-events: none;

  .artist-card:hover & { transform: scale(1.04); }
}

.cover-gradient {
  position: absolute;
  inset: 0;
  background: linear-gradient(to bottom, transparent 40%, rgba(10,8,5,0.5));
}

.verified-badge {
  position: absolute;
  top: 0.75rem;
  right: 0.75rem;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: var(--color-gold);
  color: #fff;
  font-size: 0.7rem;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
}

.artist-info {
  padding: 0 1.25rem 1.25rem;
  text-align: center;
}

.artist-avatar {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid var(--color-bg-card);
  margin-top: -32px;
  position: relative;
  z-index: 1;
  display: block;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 0.75rem;
}

.artist-name {
  font-family: var(--font-display);
  font-size: 1.2rem;
  font-weight: 400;
  color: var(--color-text-primary);
  margin-bottom: 0.25rem;
}

.artist-specialty {
  font-size: 0.8rem;
  color: var(--color-gold);
  font-weight: 500;
  letter-spacing: 0.04em;
  margin-bottom: 0.75rem;
}

.artist-stats {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  font-size: 0.8rem;
  color: var(--color-text-muted);
  margin-bottom: 1rem;
}

.divider-dot { color: var(--color-border-strong); }

.follow-btn {
  width: 100%;
  padding: 0.625rem;
  font-size: 0.8125rem;
  border-radius: 4px;
}
</style>
