<template>
  <section class="hero">
    <!-- Three.js canvas -->
    <canvas ref="canvasEl" class="hero-canvas" />

    <!-- Grain overlay -->
    <div class="hero-grain" />

    <!-- Content -->
    <div class="hero-content">
      <p class="section-label animate-on-scroll">{{ tBy({ en: 'Cambodia\'s Art Sanctuary', km: 'ដំណាក់សិល្បៈខ្មែរ' }) }}</p>

      <h1 class="hero-title animate-on-scroll" style="animation-delay: 0.15s">
        <span class="line">{{ tBy({ en: 'Where Khmer', km: 'កន្លែងដែល' }) }}</span>
        <span class="line italic gold-text">{{ tBy({ en: 'Stories', km: 'រឿងរ៉ាវខ្មែរ' }) }}</span>
        <span class="line">{{ tBy({ en: 'Live in Art', km: 'រស់នៅក្នុងសិល្បៈ' }) }}</span>
      </h1>

      <p class="hero-subtitle animate-on-scroll" style="animation-delay: 0.3s">
        {{ tBy({
          en: 'Discover, collect, and celebrate Cambodia\'s most extraordinary artists — from classical Apsara traditions to bold contemporary visions.',
          km: 'រកឃើញ ប្រមូល និងអបអរ — ពីអប្សរបុរាណ ដល់ស្នាដៃសម័យទំនើប'
        }) }}
      </p>

      <div class="hero-actions animate-on-scroll" style="animation-delay: 0.45s">
        <NuxtLink to="/gallery" class="btn btn-primary">
          {{ t('hero.cta_explore') }}
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>
          </svg>
        </NuxtLink>
        <NuxtLink to="/register" class="btn btn-outline">
          {{ t('hero.cta_join') }}
        </NuxtLink>
      </div>

      <!-- Stats row -->
      <div class="hero-stats animate-on-scroll" style="animation-delay: 0.6s">
        <div v-for="s in stats" :key="s.label" class="stat">
          <span class="stat-num">{{ s.value }}</span>
          <span class="stat-label">{{ tBy(s.label) }}</span>
        </div>
      </div>
    </div>

    <!-- Scroll indicator -->
    <a href="#featured" class="scroll-indicator animate-on-scroll" style="animation-delay: 0.9s">
      <span class="scroll-text">{{ t('hero.scroll') }}</span>
      <div class="scroll-line">
        <div class="scroll-dot" />
      </div>
    </a>
  </section>
</template>

<script setup lang="ts">
import { useTBy } from '~/composables/useTBy'
const { t } = useI18n()
const { tBy } = useTBy()

const canvasEl = ref<HTMLCanvasElement | null>(null)

const stats = [
  { value: '2,400+', label: { en: 'Artworks', km: 'ស្នាដៃ' } },
  { value: '380+',   label: { en: 'Artists',  km: 'វិចិត្រករ' } },
  { value: '12K+',   label: { en: 'Collectors', km: 'អ្នកប្រមូល' } },
  { value: '45',     label: { en: 'Countries', km: 'ប្រទេស' } },
]

// Three.js particle field
onMounted(async () => {
  if (!canvasEl.value) return

  const THREE = await import('three')
  const canvas = canvasEl.value
  const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true })
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  renderer.setSize(window.innerWidth, window.innerHeight)

  const scene = new THREE.Scene()
  const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000)
  camera.position.z = 5

  // Particle geometry
  const count = 1800
  const positions = new Float32Array(count * 3)
  for (let i = 0; i < count * 3; i++) {
    positions[i] = (Math.random() - 0.5) * 20
  }

  const geo = new THREE.BufferGeometry()
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3))

  const mat = new THREE.PointsMaterial({
    size: 0.04,
    color: 0xc8951c,
    transparent: true,
    opacity: 0.55,
    sizeAttenuation: true,
  })

  const particles = new THREE.Points(geo, mat)
  scene.add(particles)

  // Secondary smaller particles
  const geo2 = new THREE.BufferGeometry()
  const pos2 = new Float32Array(800 * 3)
  for (let i = 0; i < 800 * 3; i++) pos2[i] = (Math.random() - 0.5) * 24
  geo2.setAttribute('position', new THREE.BufferAttribute(pos2, 3))
  const mat2 = new THREE.PointsMaterial({ size: 0.02, color: 0xe8c85a, transparent: true, opacity: 0.3 })
  scene.add(new THREE.Points(geo2, mat2))

  let mouseX = 0, mouseY = 0
  const handleMouse = (e: MouseEvent) => {
    mouseX = (e.clientX / window.innerWidth - 0.5) * 2
    mouseY = -(e.clientY / window.innerHeight - 0.5) * 2
  }
  window.addEventListener('mousemove', handleMouse)

  const handleResize = () => {
    camera.aspect = window.innerWidth / window.innerHeight
    camera.updateProjectionMatrix()
    renderer.setSize(window.innerWidth, window.innerHeight)
  }
  window.addEventListener('resize', handleResize)

  let frame = 0
  let animId: number
  const animate = () => {
    animId = requestAnimationFrame(animate)
    frame += 0.002
    particles.rotation.y = frame + mouseX * 0.3
    particles.rotation.x = frame * 0.3 + mouseY * 0.2
    mat.opacity = 0.4 + Math.sin(frame * 2) * 0.1
    renderer.render(scene, camera)
  }
  animate()

  onUnmounted(() => {
    cancelAnimationFrame(animId)
    window.removeEventListener('mousemove', handleMouse)
    window.removeEventListener('resize', handleResize)
    renderer.dispose()
    geo.dispose()
    mat.dispose()
  })
})
</script>

<style scoped lang="scss">
.hero {
  position: relative;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  background: var(--color-bg);
}

.hero-canvas {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  z-index: 0;
}

.hero-grain {
  position: absolute;
  inset: 0;
  z-index: 1;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.03'/%3E%3C/svg%3E");
  pointer-events: none;
  opacity: 0.6;
}

.hero-content {
  position: relative;
  z-index: 2;
  text-align: center;
  max-width: 800px;
  padding: 0 2rem;
}

.section-label {
  margin-bottom: 1.5rem;
  opacity: 0;
  animation: fadeUp 0.8s ease forwards;
}

.hero-title {
  font-family: var(--font-display);
  font-size: clamp(3rem, 8vw, 6.5rem);
  font-weight: 400;
  line-height: 1.05;
  letter-spacing: -0.02em;
  margin-bottom: 1.5rem;

  .line {
    display: block;
    opacity: 0;
    animation: fadeUp 0.8s ease forwards;

    &:nth-child(1) { animation-delay: 0.1s; }
    &:nth-child(2) { animation-delay: 0.2s; font-style: italic; }
    &:nth-child(3) { animation-delay: 0.3s; }
  }
}

.hero-subtitle {
  font-size: clamp(0.9rem, 2vw, 1.05rem);
  color: var(--color-text-secondary);
  max-width: 560px;
  margin: 0 auto 2.5rem;
  line-height: 1.75;
  opacity: 0;
  animation: fadeUp 0.8s 0.3s ease forwards;
}

.hero-actions {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  margin-bottom: 3.5rem;
  flex-wrap: wrap;
  opacity: 0;
  animation: fadeUp 0.8s 0.45s ease forwards;
}

.hero-stats {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 3rem;
  padding-top: 2rem;
  border-top: 1px solid var(--color-border);
  flex-wrap: wrap;
  gap: 2rem;
  opacity: 0;
  animation: fadeUp 0.8s 0.6s ease forwards;
}

.stat {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.25rem;
}

.stat-num {
  font-family: var(--font-display);
  font-size: 1.75rem;
  font-weight: 500;
  color: var(--color-text-primary);
  line-height: 1;
}

.stat-label {
  font-size: 0.7rem;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  color: var(--color-text-muted);
}

.scroll-indicator {
  position: absolute;
  bottom: 2.5rem;
  left: 50%;
  transform: translateX(-50%);
  z-index: 2;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.75rem;
  text-decoration: none;
  opacity: 0;
  animation: fadeIn 1s 0.9s ease forwards;
}

.scroll-text {
  font-size: 0.65rem;
  letter-spacing: 0.25em;
  text-transform: uppercase;
  color: var(--color-text-muted);
}

.scroll-line {
  width: 1px;
  height: 48px;
  background: var(--color-border-strong);
  position: relative;
  overflow: hidden;
}

.scroll-dot {
  width: 100%;
  height: 12px;
  background: var(--color-gold);
  animation: scrollDot 1.8s ease-in-out infinite;
}

@keyframes scrollDot {
  0% { transform: translateY(-12px); }
  100% { transform: translateY(48px); }
}

@keyframes fadeUp {
  0% { opacity: 0; transform: translateY(24px); }
  100% { opacity: 1; transform: translateY(0); }
}

@keyframes fadeIn {
  to { opacity: 1; }
}
</style>
