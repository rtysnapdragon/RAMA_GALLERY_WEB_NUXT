<template>
  <section class="section testimonials-section">
    <div class="container">
      <div class="section-head animate-on-scroll">
        <p class="section-label">{{ t('home.testimonial_title') }}</p>
        <h2 class="section-title">{{ tBy({ en: 'Voices of Creators', km: 'សំឡេងរបស់វិចិត្រករ' }) }}</h2>
      </div>

      <div class="testimonials-grid">
        <div
          v-for="(t2, i) in testimonials"
          :key="t2.id"
          class="testimonial-card animate-on-scroll"
          :style="{ animationDelay: `${i * 0.12}s` }"
        >
          <div class="quote-mark">"</div>
          <p class="quote-text">{{ tBy(t2.quote) }}</p>
          <div class="quote-author">
            <img :src="t2.avatar" :alt="t2.name" class="author-avatar" />
            <div>
              <p class="author-name">{{ t2.name }}</p>
              <p class="author-role">{{ tBy(t2.role) }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import pagesData from '~/assets/json/pages.json'
import { useTBy } from '~/composables/useTBy'
const { t } = useI18n()
const { tBy } = useTBy()
const testimonials = pagesData.testimonials
</script>

<style scoped lang="scss">
.testimonials-section {
  padding: var(--section-gap) 0;
}

.container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2rem;
}

.section-head {
  text-align: center;
  margin-bottom: 3rem;
}

.section-title {
  font-size: clamp(2rem, 4vw, 2.75rem);
  margin: 0.5rem 0 0;
}

.testimonials-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
}

.testimonial-card {
  background: var(--color-bg-card);
  border: 1px solid var(--color-border);
  border-radius: 8px;
  padding: 2rem;
  position: relative;
  transition: all var(--transition);

  &:hover {
    border-color: var(--color-gold);
    transform: translateY(-2px);
  }
}

.quote-mark {
  font-family: var(--font-display);
  font-size: 4rem;
  line-height: 0.8;
  color: var(--color-gold);
  opacity: 0.4;
  margin-bottom: 1rem;
}

.quote-text {
  font-size: 0.9375rem;
  color: var(--color-text-secondary);
  line-height: 1.75;
  margin-bottom: 1.5rem;
  font-style: italic;
}

.quote-author {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding-top: 1.25rem;
  border-top: 1px solid var(--color-border);
}

.author-avatar {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid var(--color-gold);
}

.author-name {
  font-weight: 500;
  font-size: 0.9rem;
  color: var(--color-text-primary);
  margin-bottom: 0.125rem;
}

.author-role {
  font-size: 0.78rem;
  color: var(--color-text-muted);
}
</style>
