<template>
  <section id="featured" class="section">
    <div class="container">
      <div class="section-head animate-on-scroll">
        <p class="section-label">{{ t('home.featured_title') }}</p>
        <h2 class="section-title">{{ tBy({ en: 'Curated Masterpieces', km: 'ស្នាដៃជ្រើសរើស' }) }}</h2>
        <p class="section-sub">{{ t('home.featured_subtitle') }}</p>
      </div>

      <div class="masonry-grid">
        <div
          v-for="(artwork, i) in featured"
          :key="artwork.id"
          class="artwork-card animate-on-scroll"
          :style="{ animationDelay: `${i * 0.08}s` }"
          @mouseenter="hoveredId = artwork.id"
          @mouseleave="hoveredId = null"
        >
          <NuxtLink :to="`/artwork/${artwork.slug}`" class="card-link">
            <div class="card-image-wrap">
              <RAImage
                :src="artwork.image"
                :alt="artwork.title"
                ratio="unset"
                cover
                class="card-image"
              />
              <!-- Hover overlay -->
              <div class="card-overlay" :class="{ visible: hoveredId === artwork.id }">
                <div class="overlay-actions">
                  <button class="ov-btn" @click.prevent="toggleLike(artwork.id)">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                    </svg>
                    {{ artwork.likes + (likedIds.has(artwork.id) ? 1 : 0) }}
                  </button>
                  <button class="ov-btn" @click.prevent="toggleSave(artwork.id)">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                      <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
                    </svg>
                  </button>
                </div>
              </div>
            </div>

            <div class="card-info">
              <div class="card-meta">
                <span class="tag tag-sm">{{ artwork.category }}</span>
                <span class="card-year">{{ artwork.year }}</span>
              </div>
              <h3 class="card-title">{{ artwork.title }}</h3>
              <NuxtLink
                :to="`/artists/${artwork.artist.slug}`"
                class="card-artist"
                @click.stop
              >
                <img :src="artwork.artist.avatar" :alt="artwork.artist.name" class="artist-mini-avatar" />
                <span>{{ artwork.artist.name }}</span>
              </NuxtLink>
            </div>
          </NuxtLink>
        </div>
      </div>

      <div class="section-cta animate-on-scroll">
        <NuxtLink to="/gallery" class="btn btn-outline">
          {{ t('common.view_all') }} Gallery
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
            <path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>
          </svg>
        </NuxtLink>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import pagesData from '~/assets/json/pages.json'
import { useTBy } from '~/composables/useTBy'

const { t } = useI18n()
const { tBy } = useTBy()
const auth = useAuthStore()
const router = useRouter()
const localePath = useLocalePath()

const featured = pagesData.artworks.filter(a => a.featured)
const hoveredId = ref<number | null>(null)
const likedIds = ref<Set<number>>(new Set())
const savedIds = ref<Set<number>>(new Set())

const toggleLike = (id: number) => {
  if (!auth.isLoggedIn) return router.push(localePath('/login'))
  likedIds.value.has(id) ? likedIds.value.delete(id) : likedIds.value.add(id)
}

const toggleSave = (id: number) => {
  if (!auth.isLoggedIn) return router.push(localePath('/login'))
  savedIds.value.has(id) ? savedIds.value.delete(id) : savedIds.value.add(id)
}
</script>

<style scoped lang="scss">
.section {
  padding: var(--section-gap) 0;
}

.container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2rem;
}

.section-head {
  text-align: center;
  margin-bottom: 3.5rem;
}

.section-title {
  font-size: clamp(2rem, 4vw, 3rem);
  margin: 0.5rem 0 1rem;
  color: var(--color-text-primary);
}

.section-sub {
  font-size: 1rem;
  color: var(--color-text-secondary);
  max-width: 480px;
  margin: 0 auto;
}

.artwork-card {
  break-inside: avoid;
  margin-bottom: 1.5rem;
  border-radius: 4px;
  overflow: hidden;
  background: var(--color-bg-card);
  border: 1px solid var(--color-border);
  transition: all var(--transition);

  &:hover {
    border-color: var(--color-border-strong);
    transform: translateY(-3px);
    box-shadow: 0 16px 48px rgba(26,22,18,0.1);
  }
}

.dark .artwork-card:hover {
  box-shadow: 0 16px 48px rgba(0,0,0,0.3);
}

.card-link { display: block; text-decoration: none; }

.card-image-wrap {
  position: relative;
  overflow: hidden;

  .card-image { min-height: 200px; }
}

.card-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(to top, rgba(10,8,5,0.7) 0%, transparent 60%);
  opacity: 0;
  transition: opacity 0.3s ease;
  display: flex;
  align-items: flex-end;
  padding: 1rem;

  &.visible { opacity: 1; }
}

.overlay-actions {
  display: flex;
  gap: 0.5rem;
}

.ov-btn {
  display: flex;
  align-items: center;
  gap: 0.375rem;
  padding: 0.5rem 0.875rem;
  background: rgba(255,255,255,0.15);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 2px;
  color: #fff;
  font-size: 0.75rem;
  font-weight: 500;
  cursor: pointer;
  transition: all var(--transition);

  &:hover {
    background: rgba(200, 149, 28, 0.6);
    border-color: var(--color-gold);
  }
}

.card-info {
  padding: 1rem 1rem 1.125rem;
}

.card-meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 0.5rem;
}

.tag-sm {
  padding: 0.2rem 0.6rem;
  font-size: 0.65rem;
}

.card-year {
  font-size: 0.75rem;
  color: var(--color-text-muted);
}

.card-title {
  font-family: var(--font-display);
  font-size: 1.1rem;
  font-weight: 400;
  color: var(--color-text-primary);
  margin-bottom: 0.625rem;
  line-height: 1.3;
}

.card-artist {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  text-decoration: none;
  color: var(--color-text-muted);
  font-size: 0.8rem;
  transition: color var(--transition);

  &:hover { color: var(--color-gold); }
}

.artist-mini-avatar {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  object-fit: cover;
}

.section-cta {
  display: flex;
  justify-content: center;
  margin-top: 3rem;
}
</style>
