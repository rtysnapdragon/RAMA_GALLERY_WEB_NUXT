<template>
  <div class="home-page">
    <div class="welcome-card card">
      <div class="wc-icon">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L4 7v10l8 5 8-5V7L12 2z" fill="var(--accent)" stroke="var(--accent)" stroke-width="1.5" stroke-linejoin="round"/>
        </svg>
      </div>
      <h2>Welcome back, John 👋</h2>
      <p>Here's what's happening with your store today.</p>
      <NuxtLink to="/products" class="go-btn">
        View Products Dashboard →
      </NuxtLink>
    </div>

    <!-- Quick stats -->
    <div class="quick-grid">
      <div class="card quick-card" v-for="s in quickStats" :key="s.label">
        <div class="qc-label">{{ s.label }}</div>
        <div class="qc-val">{{ s.value }}</div>
        <span class="badge" :class="s.up ? 'badge-green' : 'badge-red'">
          {{ s.change }}
        </span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ layout: 'default' })
useHead({ title: 'Home' })

const quickStats = [
  { label: 'Revenue',    value: '$128,459', change: '+22% ↗', up: true },
  { label: 'Orders',     value: '3,847',    change: '+8% ↗',  up: true },
  { label: 'Customers',  value: '12,041',   change: '+14% ↗', up: true },
  { label: 'Churn Rate', value: '2.4%',     change: '-3% ↘',  up: false },
]
</script>

<style scoped>
.home-page { display: flex; flex-direction: column; gap: 16px; }

.welcome-card {
  padding: 32px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  align-items: flex-start;
}

.wc-icon {
  width: 52px;
  height: 52px;
  background: var(--accent-dim);
  border-radius: 14px;
  display: grid;
  place-items: center;
}

.welcome-card h2 {
  font-size: 22px;
  font-weight: 800;
  letter-spacing: -0.03em;
}

.welcome-card p {
  color: var(--text-2);
  font-size: 13.5px;
}

.go-btn {
  margin-top: 6px;
  padding: 9px 18px;
  background: var(--accent);
  border-radius: 10px;
  font-size: 13.5px;
  font-weight: 600;
  transition: all 0.15s;
}
.go-btn:hover { background: var(--accent-hover); transform: translateY(-1px); }

.quick-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 14px;
}

.quick-card {
  padding: 18px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.qc-label { font-size: 11.5px; color: var(--text-3); }
.qc-val { font-family: var(--font-head); font-size: 24px; font-weight: 800; letter-spacing: -0.04em; }

@media (max-width: 768px) {
  .quick-grid { grid-template-columns: 1fr 1fr; }
}
</style>
