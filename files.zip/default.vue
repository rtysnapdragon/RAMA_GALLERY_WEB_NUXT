<template>
  <div class="shell">
    <!-- Sidebar -->
    <aside class="sidebar" :class="{ collapsed: sidebarCollapsed }">
      <!-- Logo -->
      <div class="sidebar-logo">
        <div class="logo-icon">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M12 2L4 7v10l8 5 8-5V7L12 2z" fill="var(--accent)" stroke="var(--accent)" stroke-width="1.5" stroke-linejoin="round"/>
            <path d="M12 12l8-5M12 12v10M12 12L4 7" stroke="var(--text-1)" stroke-width="1" opacity="0.3"/>
          </svg>
        </div>
        <span class="logo-name" v-if="!sidebarCollapsed">Stockly</span>
        <button class="collapse-btn" @click="sidebarCollapsed = !sidebarCollapsed" :title="sidebarCollapsed ? 'Expand' : 'Collapse'">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path :d="sidebarCollapsed ? 'M9 18l6-6-6-6' : 'M15 18l-6-6 6-6'"/>
          </svg>
        </button>
      </div>

      <!-- Nav -->
      <nav class="sidebar-nav">
        <div class="nav-section">
          <span class="nav-label" v-if="!sidebarCollapsed">Main</span>
          <NuxtLink v-for="item in mainNav" :key="item.to" :to="item.to" class="nav-item" :class="{ active: route.path === item.to }" :title="item.label">
            <span class="nav-icon" v-html="item.icon"></span>
            <span class="nav-text" v-if="!sidebarCollapsed">{{ item.label }}</span>
            <span v-if="item.badge && !sidebarCollapsed" class="nav-badge">{{ item.badge }}</span>
          </NuxtLink>
        </div>

        <div class="nav-section">
          <span class="nav-label" v-if="!sidebarCollapsed">Catalog</span>
          <NuxtLink v-for="item in catalogNav" :key="item.to" :to="item.to" class="nav-item" :class="{ active: route.path === item.to }" :title="item.label">
            <span class="nav-icon" v-html="item.icon"></span>
            <span class="nav-text" v-if="!sidebarCollapsed">{{ item.label }}</span>
          </NuxtLink>
        </div>
      </nav>

      <!-- User -->
      <div class="sidebar-footer">
        <div class="sidebar-user">
          <div class="user-avatar">JS</div>
          <div class="user-info" v-if="!sidebarCollapsed">
            <span class="user-name">John Smith</span>
            <span class="user-role">Super Admin</span>
          </div>
          <button class="user-more" v-if="!sidebarCollapsed">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/></svg>
          </button>
        </div>
      </div>
    </aside>

    <!-- Main -->
    <div class="main-wrap">
      <!-- Top Header -->
      <header class="topbar">
        <!-- Left: page title area -->
        <div class="topbar-left">
          <h1 class="topbar-title">{{ pageTitle }}</h1>
        </div>

        <!-- Center Nav -->
        <nav class="topbar-nav">
          <NuxtLink v-for="item in topNav" :key="item.to" :to="item.to" class="topnav-item" :class="{ active: route.path === item.to }">
            <span v-if="item.icon" class="topnav-icon" v-html="item.icon"></span>
            {{ item.label }}
            <span v-if="item.badge" class="topnav-badge">{{ item.badge }}</span>
          </NuxtLink>
        </nav>

        <!-- Right Actions -->
        <div class="topbar-right">
          <!-- Search -->
          <div class="search-box">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            <input type="text" placeholder="Search here..." />
            <kbd>⌘K</kbd>
          </div>

          <!-- Export -->
          <button class="topbar-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Export CSV
          </button>
          <button class="topbar-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            Download Report
          </button>

          <!-- Icons -->
          <button class="icon-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/></svg>
          </button>
          <button class="icon-btn notif-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
            <span class="notif-dot"></span>
          </button>
        </div>
      </header>

      <!-- Page Content -->
      <main class="page-content">
        <slot />
      </main>
    </div>
  </div>
</template>

<script setup lang="ts">
const route = useRoute()
const sidebarCollapsed = ref(false)

const pageTitle = computed(() => {
  const map: Record<string, string> = {
    '/': 'Dashboard',
    '/products': 'Products',
    '/customers': 'Customers',
    '/calendar': 'Calendar',
    '/chat': 'Chat',
  }
  return map[route.path] ?? 'Dashboard'
})

const iconSize = '16'

const mainNav = [
  {
    to: '/',
    label: 'Home',
    icon: `<svg width="${iconSize}" height="${iconSize}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>`,
  },
  {
    to: '/calendar',
    label: 'Calendar',
    icon: `<svg width="${iconSize}" height="${iconSize}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>`,
  },
  {
    to: '/customers',
    label: 'Customers',
    icon: `<svg width="${iconSize}" height="${iconSize}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
  },
  {
    to: '/products',
    label: 'Products',
    icon: `<svg width="${iconSize}" height="${iconSize}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/></svg>`,
  },
  {
    to: '/chat',
    label: 'Chat',
    badge: 78,
    icon: `<svg width="${iconSize}" height="${iconSize}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>`,
  },
]

const catalogNav = [
  {
    to: '/inventory',
    label: 'Inventory',
    icon: `<svg width="${iconSize}" height="${iconSize}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>`,
  },
  {
    to: '/analytics',
    label: 'Analytics',
    icon: `<svg width="${iconSize}" height="${iconSize}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>`,
  },
  {
    to: '/settings',
    label: 'Settings',
    icon: `<svg width="${iconSize}" height="${iconSize}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/></svg>`,
  },
]

const topNav = [
  { to: '/', label: 'Home' },
  { to: '/calendar', label: 'Calendar' },
  { to: '/customers', label: 'Customers' },
  {
    to: '/products',
    label: 'Products',
    icon: `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/></svg>`,
  },
  { to: '/chat', label: 'Chat', badge: 78 },
]
</script>

<style scoped>
/* ── Shell ── */
.shell {
  display: flex;
  min-height: 100vh;
  background: var(--bg);
}

/* ── Sidebar ── */
.sidebar {
  width: var(--sidebar-w);
  min-height: 100vh;
  background: var(--surface);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  flex-shrink: 0;
  transition: width 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  position: sticky;
  top: 0;
  height: 100vh;
  overflow: hidden;
  z-index: 50;
}

.sidebar.collapsed {
  width: 62px;
}

.sidebar-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 18px 16px;
  border-bottom: 1px solid var(--border);
  min-height: var(--header-h);
}

.logo-icon {
  width: 32px;
  height: 32px;
  background: var(--accent-dim);
  border-radius: 8px;
  display: grid;
  place-items: center;
  flex-shrink: 0;
}

.logo-name {
  font-family: var(--font-head);
  font-size: 17px;
  font-weight: 800;
  letter-spacing: -0.03em;
  flex: 1;
  white-space: nowrap;
}

.collapse-btn {
  width: 22px;
  height: 22px;
  border-radius: 6px;
  display: grid;
  place-items: center;
  color: var(--text-3);
  transition: all 0.15s;
  flex-shrink: 0;
}
.collapse-btn:hover { background: var(--surface-2); color: var(--text-1); }

.sidebar-nav {
  flex: 1;
  padding: 12px 10px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.nav-section {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.nav-label {
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--text-3);
  padding: 0 8px 6px;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 10px;
  border-radius: 9px;
  color: var(--text-2);
  font-size: 13.5px;
  font-weight: 500;
  transition: all 0.15s;
  white-space: nowrap;
  position: relative;
}

.nav-item:hover {
  background: var(--surface-2);
  color: var(--text-1);
}

.nav-item.active {
  background: var(--accent);
  color: var(--text-1);
  font-weight: 600;
}

.nav-icon {
  width: 20px;
  height: 20px;
  display: grid;
  place-items: center;
  flex-shrink: 0;
}

.nav-text { flex: 1; }

.nav-badge {
  background: var(--text-1);
  color: var(--surface);
  font-size: 10px;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 99px;
  .nav-item.active & { background: rgba(0,0,0,0.15); color: var(--text-1); }
}

/* Footer / User */
.sidebar-footer {
  padding: 10px;
  border-top: 1px solid var(--border);
}

.sidebar-user {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px;
  border-radius: 10px;
  transition: background 0.15s;
  cursor: pointer;
}
.sidebar-user:hover { background: var(--surface-2); }

.user-avatar {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: var(--accent);
  display: grid;
  place-items: center;
  font-size: 11px;
  font-weight: 700;
  flex-shrink: 0;
}

.user-info {
  flex: 1;
  min-width: 0;
}
.user-name {
  display: block;
  font-size: 12.5px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.user-role {
  display: block;
  font-size: 11px;
  color: var(--text-3);
}

.user-more {
  color: var(--text-3);
  width: 20px;
  height: 20px;
  display: grid;
  place-items: center;
}

/* ── Main wrap ── */
.main-wrap {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
}

/* ── Topbar ── */
.topbar {
  height: var(--header-h);
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 0 20px;
  position: sticky;
  top: 0;
  z-index: 40;
}

.topbar-left {
  display: flex;
  align-items: center;
  min-width: 0;
}
.topbar-title {
  font-size: 15px;
  font-weight: 700;
  letter-spacing: -0.02em;
  white-space: nowrap;
}

.topbar-nav {
  display: flex;
  align-items: center;
  gap: 2px;
  flex: 1;
  justify-content: center;
}

.topnav-item {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 6px 14px;
  border-radius: 99px;
  font-size: 13px;
  font-weight: 500;
  color: var(--text-2);
  transition: all 0.15s;
  white-space: nowrap;
}
.topnav-item:hover { background: var(--surface-2); color: var(--text-1); }
.topnav-item.active {
  background: var(--accent);
  color: var(--text-1);
  font-weight: 600;
}

.topnav-badge {
  background: var(--text-1);
  color: var(--surface);
  font-size: 10px;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 99px;
}
.topnav-item.active .topnav-badge {
  background: rgba(0,0,0,0.15);
}

.topbar-right {
  display: flex;
  align-items: center;
  gap: 8px;
}

.search-box {
  display: flex;
  align-items: center;
  gap: 7px;
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: 9px;
  padding: 6px 10px;
  width: 200px;
  transition: border-color 0.15s;
}
.search-box:focus-within {
  border-color: var(--text-3);
}
.search-box svg { color: var(--text-3); flex-shrink: 0; }
.search-box input {
  flex: 1;
  border: none;
  background: none;
  outline: none;
  font-size: 12.5px;
  color: var(--text-1);
  min-width: 0;
}
.search-box input::placeholder { color: var(--text-3); }
.search-box kbd {
  font-size: 10px;
  color: var(--text-3);
  background: var(--border);
  padding: 1px 5px;
  border-radius: 4px;
}

.topbar-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: 9px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--text-2);
  transition: all 0.15s;
  white-space: nowrap;
}
.topbar-btn:hover { border-color: var(--text-3); color: var(--text-1); }

.icon-btn {
  width: 34px;
  height: 34px;
  border-radius: 9px;
  display: grid;
  place-items: center;
  background: var(--surface-2);
  border: 1px solid var(--border);
  color: var(--text-2);
  transition: all 0.15s;
  position: relative;
}
.icon-btn:hover { border-color: var(--text-3); color: var(--text-1); }

.notif-dot {
  position: absolute;
  top: 7px;
  right: 7px;
  width: 7px;
  height: 7px;
  background: #EF4444;
  border-radius: 50%;
  border: 1.5px solid var(--surface);
}

/* ── Page content ── */
.page-content {
  flex: 1;
  padding: 20px;
  overflow-x: hidden;
}

/* ── Responsive ── */
@media (max-width: 1024px) {
  .topbar-nav { display: none; }
  .search-box { width: 160px; }
  .topbar-btn:last-of-type { display: none; }
}

@media (max-width: 768px) {
  .sidebar { display: none; }
  .topbar-btn { display: none; }
  .search-box { display: none; }
}
</style>
