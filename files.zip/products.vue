<template>
  <div class="products-page">

    <!-- Page header row -->
    <div class="page-header">
      <div>
        <h2 class="page-title">Products</h2>
        <p class="page-sub">Manage, track, and analyze products in one place.</p>
      </div>

      <!-- Category filter chips -->
      <div class="category-chips">
        <button
          v-for="cat in categories"
          :key="cat"
          class="chip"
          :class="{ active: activeCategory === cat }"
          @click="activeCategory = cat"
        >{{ cat }}</button>
        <button class="chip chip-more">+14</button>
      </div>

      <button class="icon-btn-sm" title="Refresh">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
      </button>
    </div>

    <!-- Top metric cards -->
    <div class="metrics-row">
      <!-- Inventory -->
      <div class="card metric-card">
        <div class="metric-top">
          <div class="metric-label">Inventory</div>
          <DonutChart
            :size="90"
            :stroke-width="10"
            :segments="[
              { value: 42, color: '#E8E04A' },
              { value: 58, color: '#EBEBEB' },
            ]"
            center-label="42%"
            center-sub="Digital Goods"
          />
        </div>
        <div class="metric-value">3,21,767</div>
        <div class="metric-footer">
          <span class="metric-period">Then Last Month</span>
          <span class="badge badge-green">+16% ↗</span>
        </div>
      </div>

      <!-- Total Product Sell -->
      <div class="card metric-card">
        <div class="metric-top">
          <div>
            <div class="metric-label">Total Product Sell</div>
          </div>
          <div class="metric-icon-box">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
          </div>
        </div>
        <div class="metric-value">89,922</div>
        <div class="metric-footer">
          <span class="metric-period">Then Last Month</span>
          <span class="badge badge-green">+12% ↗</span>
        </div>
      </div>

      <!-- Churn Rate -->
      <div class="card metric-card">
        <div class="metric-top">
          <div>
            <div class="metric-label">Churn Rate</div>
          </div>
          <div class="metric-icon-box">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
          </div>
        </div>
        <div class="metric-value">12%</div>
        <div class="metric-footer">
          <span class="metric-period">Then Last Month</span>
          <span class="badge badge-red">-14% ↘</span>
        </div>
      </div>

      <!-- Product Sales Breakdown -->
      <div class="card breakdown-card">
        <div class="breakdown-header">
          <div>
            <div class="card-title">Product Sales Breakdown</div>
            <div class="card-sub">Analyze Product Performance And Key Metrics</div>
          </div>
          <div class="period-toggle">
            <button class="period-btn active">Monthly</button>
          </div>
        </div>

        <div class="breakdown-body">
          <DonutChart
            :size="110"
            :stroke-width="14"
            :segments="[
              { value: 35, color: '#E8E04A' },
              { value: 20, color: '#D4C5A9' },
              { value: 25, color: '#141414' },
              { value: 20, color: '#EBEBEB' },
            ]"
            center-label="12%"
            center-sub="Monthly Growth"
          />

          <div class="breakdown-stats">
            <div class="stat-item">
              <div class="stat-icon-box" style="background:#FFF9CC">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
              </div>
              <div>
                <div class="stat-cat">Electronics</div>
                <div class="stat-val">$89,922</div>
              </div>
            </div>
            <div class="stat-item">
              <div class="stat-icon-box" style="background:#F5F0E8">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.57a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.57a2 2 0 0 0-1.34-2.23z"/></svg>
              </div>
              <div>
                <div class="stat-cat">Clothes</div>
                <div class="stat-val">$21,082</div>
              </div>
            </div>
            <div class="stat-item">
              <div class="stat-icon-box" style="background:#EEF2FF">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
              </div>
              <div>
                <div class="stat-cat">Tools</div>
                <div class="stat-val">$41,954</div>
              </div>
            </div>
            <div class="stat-item">
              <div class="stat-icon-box" style="background:#FFF0F0">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>
              </div>
              <div>
                <div class="stat-cat">Furniture</div>
                <div class="stat-val">$17,562</div>
              </div>
            </div>
          </div>

          <div class="breakdown-total">
            <div class="bt-icon">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
            </div>
            <div class="bt-label">Total Product Sell</div>
            <div class="bt-val">89,922</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Bottom row -->
    <div class="bottom-row">
      <!-- Demand & Supply chart -->
      <div class="card demand-card">
        <div class="demand-header">
          <div>
            <div class="card-title">Demand & Supply</div>
            <div class="card-sub">Track Product Demand And Stock Levels</div>
          </div>
          <select class="period-select">
            <option>Monthly</option>
            <option>Weekly</option>
            <option>Yearly</option>
          </select>
        </div>

        <div class="demand-summary">
          <span class="demand-total">Total Supply: <strong>$35.56M</strong></span>
          <span class="badge badge-green">+18% ↗</span>
          <div class="demand-legend">
            <span class="legend-dot" style="background:var(--accent)"></span> Demand
            <span class="legend-dot" style="background:#C4B99A; margin-left:10px"></span> Supply
          </div>
        </div>

        <!-- Chart area -->
        <div class="chart-wrap">
          <!-- Y axis labels -->
          <div class="y-axis">
            <span v-for="l in ['6m','5m','4m','3m','2m','1m','0']" :key="l">{{ l }}</span>
          </div>
          <div class="chart-area">
            <!-- Tooltip -->
            <div class="chart-tooltip">
              <div class="tt-month">May</div>
              <div class="tt-val">$3.5M <span class="badge badge-green" style="font-size:10px">+12% ↗</span></div>
            </div>
            <SparkLine
              :data="demandData"
              color="var(--accent)"
              :height="130"
              :highlight-idx="4"
              style="position:absolute;inset:0;width:100%;height:100%"
            />
            <SparkLine
              :data="supplyData"
              color="#C4B99A"
              :height="130"
              style="position:absolute;inset:0;width:100%;height:100%;opacity:0.8"
            />
          </div>
        </div>

        <!-- X axis -->
        <div class="x-axis">
          <span v-for="m in months" :key="m">{{ m }}</span>
        </div>
      </div>

      <!-- Recent Stocks table -->
      <div class="card stocks-card">
        <div class="stocks-header">
          <div>
            <div class="card-title">Recent Stocks</div>
            <div class="card-sub">Monitor Stock Activity And Store Updates</div>
          </div>
        </div>

        <div class="table-wrap">
          <table class="stocks-table">
            <thead>
              <tr>
                <th><div class="th-check"><input type="checkbox" @change="toggleAll" :checked="allSelected" /></div></th>
                <th>Product Name</th>
                <th>Date</th>
                <th>Amount</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in stocks" :key="item.id" :class="{ selected: selectedRows.includes(item.id) }">
                <td>
                  <input type="checkbox" :checked="selectedRows.includes(item.id)" @change="toggleRow(item.id)" />
                </td>
                <td>
                  <div class="product-cell">
                    <div class="product-thumb" :style="{ background: item.color }">
                      <svg v-if="!item.img" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" opacity="0.5"><path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/></svg>
                    </div>
                    <div>
                      <div class="product-name">{{ item.name }}</div>
                      <div class="product-variants">{{ item.variants }} Variants</div>
                    </div>
                  </div>
                </td>
                <td class="date-cell">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right:5px;opacity:0.5"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                  {{ item.date }}
                </td>
                <td class="amount-cell">${{ item.amount }}</td>
                <td>
                  <div class="status-cell">
                    <span class="badge" :class="statusClass(item.status)">{{ item.status }}</span>
                    <div class="row-actions">
                      <button class="row-btn">View</button>
                      <button class="row-btn">Edit</button>
                      <button class="row-btn row-btn-del">Del</button>
                    </div>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ layout: 'default' })

useHead({ title: 'Products' })

const categories = ['Laptop', 'Watch', 'Mouse', 'Airpod', 'iMac', 'iPhone']
const activeCategory = ref('Laptop')

const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

const demandData = [1.8, 2.2, 2.0, 2.8, 3.5, 2.4, 2.9, 2.1, 3.2, 2.7, 3.8, 3.2]
const supplyData = [1.5, 1.9, 2.3, 2.5, 3.0, 2.7, 2.2, 2.8, 2.4, 3.1, 2.9, 3.5]

const stocks = [
  { id: 1, name: 'Apple Airpod 2nd Gen', variants: 2,  date: '22 Sep, 2025', amount: '289.00',  status: 'Completed', color: '#E8E8E8' },
  { id: 2, name: 'Macbook Pro 16" 32/1TB', variants: 1, date: '15 Sep, 2025', amount: '2,890.00', status: 'Completed', color: '#C0392B' },
  { id: 3, name: 'Gaming Mouse Pad',     variants: 9,  date: '15 Sep, 2025', amount: '18.00',   status: 'In Progress', color: '#2C3E50' },
  { id: 4, name: 'Apple Airpod Max',     variants: 5,  date: '12 Sep, 2025', amount: '579.00',  status: 'In Progress', color: '#BDC3C7' },
  { id: 5, name: 'Apple Magic Mouse',    variants: 3,  date: '12 Sep, 2025', amount: '108.08',  status: 'Completed', color: '#1C1C1E' },
  { id: 6, name: 'Apple Watch Ultra',    variants: 4,  date: '08 Sep, 2025', amount: '988.08',  status: 'In Progress', color: '#F5A623' },
  { id: 7, name: 'Mouse Pad',            variants: 3,  date: '05 Sep, 2025', amount: '56.98',   status: 'Completed', color: '#E0E0E0' },
]

const selectedRows = ref<number[]>([1])
const allSelected = computed(() => selectedRows.value.length === stocks.length)

function toggleRow(id: number) {
  const idx = selectedRows.value.indexOf(id)
  if (idx > -1) selectedRows.value.splice(idx, 1)
  else selectedRows.value.push(id)
}

function toggleAll(e: Event) {
  selectedRows.value = (e.target as HTMLInputElement).checked ? stocks.map(s => s.id) : []
}

function statusClass(status: string) {
  if (status === 'Completed') return 'badge-green'
  if (status === 'In Progress') return 'badge-blue'
  if (status === 'Cancelled') return 'badge-red'
  return 'badge-gray'
}
</script>

<style scoped>
/* ── Page header ── */
.products-page { display: flex; flex-direction: column; gap: 16px; }

.page-header {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}

.page-title {
  font-size: 22px;
  font-weight: 800;
  letter-spacing: -0.03em;
}
.page-sub {
  font-size: 12px;
  color: var(--text-3);
  margin-top: 2px;
}

.category-chips {
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
  flex: 1;
  justify-content: flex-end;
}

.chip {
  padding: 5px 12px;
  border-radius: 99px;
  font-size: 12.5px;
  font-weight: 500;
  background: var(--surface);
  border: 1px solid var(--border);
  color: var(--text-2);
  transition: all 0.15s;
}
.chip:hover { border-color: var(--text-3); color: var(--text-1); }
.chip.active {
  background: var(--accent);
  border-color: var(--accent);
  color: var(--text-1);
  font-weight: 600;
}
.chip-more { opacity: 0.6; }

.icon-btn-sm {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: var(--surface);
  border: 1px solid var(--border);
  display: grid;
  place-items: center;
  color: var(--text-2);
  transition: all 0.15s;
}
.icon-btn-sm:hover { color: var(--text-1); border-color: var(--text-3); }

/* ── Metrics row ── */
.metrics-row {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 2fr;
  gap: 14px;
}

.metric-card {
  padding: 18px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.metric-top {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 8px;
}

.metric-label {
  font-size: 12px;
  color: var(--text-3);
  font-style: italic;
  font-weight: 400;
}

.metric-icon-box {
  width: 36px;
  height: 36px;
  background: var(--surface-2);
  border: 1px solid var(--border);
  border-radius: 9px;
  display: grid;
  place-items: center;
  color: var(--text-2);
}

.metric-value {
  font-family: var(--font-head);
  font-size: 26px;
  font-weight: 800;
  letter-spacing: -0.04em;
  line-height: 1;
}

.metric-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: auto;
}

.metric-period {
  font-size: 11px;
  color: var(--text-3);
}

/* ── Breakdown card ── */
.breakdown-card {
  padding: 18px;
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.breakdown-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
}

.card-title { font-size: 14px; font-weight: 700; letter-spacing: -0.02em; }
.card-sub { font-size: 11px; color: var(--text-3); margin-top: 2px; }

.period-toggle { display: flex; gap: 4px; }
.period-btn {
  padding: 4px 10px;
  border-radius: 7px;
  font-size: 12px;
  font-weight: 500;
  color: var(--text-2);
  background: transparent;
  transition: all 0.15s;
}
.period-btn.active {
  background: var(--accent-dim);
  color: var(--text-1);
}

.breakdown-body {
  display: flex;
  align-items: center;
  gap: 16px;
  flex-wrap: wrap;
}

.breakdown-stats {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  flex: 1;
}

.stat-item {
  display: flex;
  align-items: center;
  gap: 8px;
}

.stat-icon-box {
  width: 28px;
  height: 28px;
  border-radius: 7px;
  display: grid;
  place-items: center;
  flex-shrink: 0;
}

.stat-cat { font-size: 11px; color: var(--text-3); }
.stat-val { font-size: 13px; font-weight: 700; letter-spacing: -0.02em; }

.breakdown-total {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 14px;
  background: var(--surface-2);
  border-radius: 10px;
  border: 1px solid var(--border);
  min-width: 140px;
}

.bt-icon {
  width: 30px;
  height: 30px;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 8px;
  display: grid;
  place-items: center;
  color: var(--text-2);
}
.bt-label { font-size: 10px; color: var(--text-3); }
.bt-val { font-size: 16px; font-weight: 800; letter-spacing: -0.03em; }

/* ── Bottom row ── */
.bottom-row {
  display: grid;
  grid-template-columns: 1fr 1.4fr;
  gap: 14px;
}

/* ── Demand chart ── */
.demand-card {
  padding: 18px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.demand-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
}

.period-select {
  padding: 5px 10px;
  border-radius: 8px;
  border: 1px solid var(--border);
  background: var(--surface-2);
  font-size: 12.5px;
  color: var(--text-2);
  outline: none;
  cursor: pointer;
  font-family: var(--font-body);
}

.demand-summary {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.demand-total {
  font-size: 12.5px;
  color: var(--text-2);
}
.demand-total strong {
  font-weight: 700;
  color: var(--text-1);
}

.demand-legend {
  margin-left: auto;
  font-size: 11.5px;
  color: var(--text-3);
  display: flex;
  align-items: center;
  gap: 4px;
}
.legend-dot {
  width: 10px;
  height: 10px;
  border-radius: 3px;
  display: inline-block;
}

.chart-wrap {
  display: flex;
  gap: 8px;
  flex: 1;
  min-height: 140px;
}

.y-axis {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 4px 0;
}
.y-axis span {
  font-size: 10.5px;
  color: var(--text-3);
  text-align: right;
  min-width: 24px;
}

.chart-area {
  flex: 1;
  position: relative;
  overflow: visible;
}

.chart-tooltip {
  position: absolute;
  top: 10px;
  left: 32%;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 9px;
  padding: 6px 10px;
  box-shadow: var(--shadow);
  z-index: 2;
  pointer-events: none;
}
.tt-month { font-size: 11px; color: var(--text-3); }
.tt-val { font-size: 13px; font-weight: 700; display: flex; align-items: center; gap: 5px; }

.x-axis {
  display: flex;
  justify-content: space-between;
  padding-left: 34px;
}
.x-axis span { font-size: 10.5px; color: var(--text-3); }

/* ── Stocks table ── */
.stocks-card {
  padding: 18px;
  display: flex;
  flex-direction: column;
  gap: 14px;
  overflow: hidden;
}

.stocks-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
}

.table-wrap { overflow-x: auto; }

.stocks-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
}

.stocks-table th {
  text-align: left;
  padding: 7px 10px;
  font-size: 11px;
  font-weight: 600;
  color: var(--text-3);
  border-bottom: 1px solid var(--border);
  white-space: nowrap;
}

.th-check { display: flex; align-items: center; }

.stocks-table td {
  padding: 9px 10px;
  border-bottom: 1px solid var(--border-2);
  vertical-align: middle;
}

.stocks-table tr:last-child td { border-bottom: none; }

.stocks-table tr.selected td { background: rgba(232,224,74,0.05); }

.stocks-table tr:hover td { background: var(--surface-2); }

.product-cell {
  display: flex;
  align-items: center;
  gap: 9px;
}

.product-thumb {
  width: 34px;
  height: 34px;
  border-radius: 8px;
  display: grid;
  place-items: center;
  flex-shrink: 0;
}

.product-name { font-weight: 600; font-size: 12.5px; }
.product-variants { font-size: 11px; color: var(--text-3); }

.date-cell {
  color: var(--text-2);
  white-space: nowrap;
  display: flex;
  align-items: center;
}

.amount-cell { font-weight: 600; font-size: 12.5px; white-space: nowrap; }

.status-cell {
  display: flex;
  align-items: center;
  gap: 8px;
}

.row-actions { display: flex; gap: 4px; }

.row-btn {
  padding: 3px 8px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 500;
  background: var(--surface-2);
  border: 1px solid var(--border);
  color: var(--text-2);
  transition: all 0.15s;
}
.row-btn:hover { border-color: var(--text-3); color: var(--text-1); }
.row-btn-del { color: var(--red); }
.row-btn-del:hover { background: var(--red-bg); border-color: var(--red); }

/* checkbox styling */
input[type="checkbox"] {
  width: 14px;
  height: 14px;
  accent-color: var(--accent);
  cursor: pointer;
}

/* ── Responsive ── */
@media (max-width: 1200px) {
  .metrics-row { grid-template-columns: 1fr 1fr; }
  .breakdown-card { grid-column: span 2; }
}

@media (max-width: 900px) {
  .bottom-row { grid-template-columns: 1fr; }
}

@media (max-width: 640px) {
  .metrics-row { grid-template-columns: 1fr; }
  .breakdown-card { grid-column: 1; }
}
</style>
